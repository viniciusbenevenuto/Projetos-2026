"""Validação do HTML renderizado de cada tela (sem servidor: Flask test client).

O prompt pede o html-validate (Node.js), que não está instalado nesta máquina.
Este verificador cobre as regras que mais quebram acessibilidade e layout:
  - ids duplicados;
  - tags não fechadas ou fechadas fora de ordem;
  - for / aria-labelledby / aria-describedby / aria-controls apontando para id inexistente;
  - img sem alt; button sem type; form dentro de form;
  - elemento interativo dentro de outro (a em button, button em a);
  - role="region" sem nome acessível.

Uso: python tools/qa/html_check.py
"""
from __future__ import annotations

import sys
from html.parser import HTMLParser

from comum import FORM_ID, RAIZ, TELAS, USUARIOS

VAZIOS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta",
          "source", "track", "wbr", "path", "circle", "rect", "line", "polyline",
          "polygon", "ellipse", "use", "stop"}
INTERATIVOS = {"a", "button"}


class Verificador(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.pilha: list[str] = []
        self.ids: dict[str, int] = {}
        self.refs: list[tuple[str, str]] = []
        self.erros: list[str] = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if "id" in a:
            self.ids[a["id"]] = self.ids.get(a["id"], 0) + 1
        for chave in ("for", "aria-labelledby", "aria-describedby", "aria-controls"):
            if a.get(chave):
                for alvo in a[chave].split():
                    self.refs.append((chave, alvo))
        if tag == "img" and "alt" not in a:
            self.erros.append(f"img sem alt: {a.get('src')}")
        if tag == "button" and "type" not in a:
            self.erros.append(f"button sem type: {a.get('id') or a.get('class')}")
        if tag == "form" and "form" in self.pilha:
            self.erros.append("form dentro de form")
        if tag in INTERATIVOS and any(t in INTERATIVOS for t in self.pilha):
            self.erros.append(f"{tag} dentro de elemento interativo")
        if a.get("role") == "region" and not (a.get("aria-label") or a.get("aria-labelledby")):
            self.erros.append("role=region sem nome acessível")
        if tag not in VAZIOS:
            self.pilha.append(tag)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in VAZIOS and self.pilha and self.pilha[-1] == tag:
            self.pilha.pop()

    def handle_endtag(self, tag):
        if tag in VAZIOS:
            return
        if tag in self.pilha:
            while self.pilha:
                topo = self.pilha.pop()
                if topo == tag:
                    break
                # p e li fecham implicitamente; o resto é erro
                if topo not in {"p", "li", "option", "tr", "td", "th", "thead", "tbody"}:
                    self.erros.append(f"<{topo}> não fechado antes de </{tag}>")
        else:
            self.erros.append(f"</{tag}> sem abertura")

    def resultado(self) -> list[str]:
        erros = list(self.erros)
        erros += [f"id duplicado: {i} ({n}x)" for i, n in self.ids.items() if n > 1]
        erros += [f"{chave} aponta para id inexistente: {alvo}" for chave, alvo in self.refs if alvo not in self.ids]
        resto = [t for t in self.pilha if t not in {"html", "body", "p", "li"}]
        if resto:
            erros.append(f"tags não fechadas no fim: {resto}")
        return erros


def main() -> int:
    sys.path.insert(0, str(RAIZ))
    from app import create_app

    app = create_app()
    cliente = app.test_client()
    total = 0
    for tela in TELAS:
        with cliente.session_transaction() as s:
            s.clear()
            if tela.perfil:
                s.update(USUARIOS[tela.perfil])
        html = cliente.get(tela.caminho).get_data(as_text=True)
        v = Verificador()
        v.feed(html)
        erros = v.resultado()
        total += len(erros)
        print(f"{'ok   ' if not erros else 'FALHA'} {tela.nome:<20} {len(erros)} erro(s)")
        for e in erros[:12]:
            print(f"      - {e}")
    print(f"\nTotal de erros: {total}")
    return 1 if total else 0


if __name__ == "__main__":
    sys.exit(main())
