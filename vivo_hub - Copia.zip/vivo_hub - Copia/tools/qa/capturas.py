"""Capturas de cada tela nas três larguras e nos três momentos (0, 1200, 4000 ms).

Uso:
    python tools/qa/capturas.py antes      # antes da repaginada
    python tools/qa/capturas.py depois     # depois

Saída: docs/repaginada/capturas/<fase>/<tela>-<largura>-<ms>.jpg
       e <tela>-<largura>-pagina.jpg (página inteira, aos 4000 ms).
"""
from __future__ import annotations

import sys
import time

from playwright.sync_api import TimeoutError as PlaywrightTimeout
from playwright.sync_api import sync_playwright

from comum import BASE_URL, CAPTURAS, LARGURAS, MOMENTOS_MS, TELAS, abrir_navegador, cookie_de_sessao


def capturar(fase: str) -> None:
    destino = CAPTURAS / fase
    destino.mkdir(parents=True, exist_ok=True)
    cookies = {perfil: cookie_de_sessao(perfil) for perfil in {t.perfil for t in TELAS}}

    with sync_playwright() as p:
        navegador = abrir_navegador(p)
        for tela in TELAS:
            for rotulo, (largura, altura) in LARGURAS.items():
                if (destino / f"{tela.nome}-{rotulo}-pagina.jpg").exists() and "--refazer" not in sys.argv:
                    continue
                contexto = navegador.new_context(viewport={"width": largura, "height": altura})
                contexto.add_cookies(cookies[tela.perfil])
                pagina = contexto.new_page()
                try:
                    pagina.goto(BASE_URL + tela.caminho, wait_until="load", timeout=20000)
                except PlaywrightTimeout:
                    # Recurso externo lento (CDN): segue a partir do DOM pronto
                    print(f"aviso {tela.nome} {rotulo}: 'load' não chegou em 20 s")
                inicio = time.monotonic()
                for ms in MOMENTOS_MS:
                    espera = ms / 1000 - (time.monotonic() - inicio)
                    if espera > 0:
                        time.sleep(espera)
                    pagina.screenshot(path=str(destino / f"{tela.nome}-{rotulo}-{ms}.jpg"),
                                      type="jpeg", quality=80)
                pagina.screenshot(path=str(destino / f"{tela.nome}-{rotulo}-pagina.jpg"),
                                  type="jpeg", quality=75, full_page=True)
                contexto.close()
            print(f"ok  {tela.nome}")
        navegador.close()
    print(f"Capturas em {destino}")


if __name__ == "__main__":
    capturar(sys.argv[1] if len(sys.argv) > 1 else "depois")
