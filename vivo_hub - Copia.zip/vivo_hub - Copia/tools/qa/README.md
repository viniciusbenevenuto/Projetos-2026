# Controle de qualidade da repaginada visual

Scripts de verificação. Ficam fora da imagem Docker e não entram no
`requirements.txt`.

## Preparação (uma vez)

```bash
pip install playwright
```

Os scripts usam o Chrome ou o Edge já instalados na máquina
(`channel="chrome"`/`"msedge"`), sem baixar navegador. Os cookies de sessão
são assinados com a `SECRET_KEY` da aplicação: nenhum usuário é criado no
banco. As telas usam os usuários de id 1 (Atacado) e 2 (Engenharia) e o PTI
#26; troque com `QA_ATACADO_ID`, `QA_ENG_ID` e `QA_FORM_ID`.

## Uso

Com a aplicação no ar (`python run.py`; endereço em `QA_BASE_URL`, padrão
`http://127.0.0.1:5000`):

| Script | O que faz |
|---|---|
| `python tools/qa/capturas.py antes` ou `depois` | Captura cada tela em 1920 × 1080, 1366 × 768 e 390 × 844, aos 0, 1200 e 4000 ms, mais a página inteira, em `docs/repaginada/capturas/<fase>/` |
| `python tools/qa/verificacoes.py` | Rolagem lateral, texto abaixo de 14 px, contraste, tokens e fontes, requisições externas, console e rede, teclado, entradas, movimento reduzido, pausa, desempenho (CPU 4× mais lenta) e formulários. Saída em `tools/qa/saida/verificacoes.json` |

Sem servidor (Flask test client):

| Script | O que faz |
|---|---|
| `python tools/qa/html_check.py` | Valida o HTML renderizado de cada tela (ids, tags, referências ARIA, botões, formulários) |
| `python tools/qa/regressao.py` | Compara com o branch `main` (antes da repaginada): status, tipo de conteúdo e redirecionamento de cada rota, e todas as células do PTI gerado para cada formulário |

## Observações

- O html-validate (Node.js) pedido no prompt não está instalado nesta
  máquina; o `html_check.py` cobre as regras principais em Python.
- A verificação de desempenho usa o protocolo do Chrome
  (`Emulation.setCPUThrottlingRate`).
- O envio do login na verificação de formulários usa credenciais fictícias e
  a requisição é abortada antes de chegar ao servidor.
