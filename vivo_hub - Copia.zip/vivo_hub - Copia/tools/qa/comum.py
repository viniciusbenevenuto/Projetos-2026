"""Utilidades comuns do controle de qualidade da repaginada visual.

- Sessões de teste assinadas com a SECRET_KEY da própria aplicação (não cria
  usuários no banco).
- Lista das telas verificadas, com o perfil de acesso de cada uma.
- Abertura do navegador (Chrome ou Edge instalados na máquina, via Playwright).

Uso: os scripts desta pasta rodam com a aplicação já no ar
(python run.py) e o pacote Playwright instalado (ver README.md).
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]          # pasta da aplicação
CAPTURAS = RAIZ / "docs" / "repaginada" / "capturas"
SAIDA = Path(__file__).resolve().parent / "saida"
BASE_URL = os.environ.get("QA_BASE_URL", "http://127.0.0.1:5000")

# Larguras do controle de qualidade (largura, altura)
LARGURAS = {"1920": (1920, 1080), "1366": (1366, 768), "390": (390, 844)}
MOMENTOS_MS = (0, 1200, 4000)

# Usuários de leitura: ids existentes no banco de desenvolvimento
USUARIOS = {
    "atacado": {"user_id": int(os.environ.get("QA_ATACADO_ID", 1)),
                "role": "atacado", "email": "qa.atacado@vivohub.local"},
    "engenharia": {"user_id": int(os.environ.get("QA_ENG_ID", 2)),
                   "role": "engenharia", "email": "qa.engenharia@vivohub.local"},
    "admin": {"is_admin": True},
}
FORM_ID = int(os.environ.get("QA_FORM_ID", 26))    # PTI usado nas telas de formulário


@dataclass(frozen=True)
class Tela:
    nome: str
    caminho: str
    perfil: str | None          # chave de USUARIOS, ou None para anônimo
    padrao: str                 # padrão do prompt (mapa de padrões)


TELAS: tuple[Tela, ...] = (
    Tela("login", "/login", None, "Login"),
    Tela("admin_login", "/admin_login", None, "Formulário"),
    Tela("register", "/register", "admin", "Formulário"),
    Tela("central_atacado", "/central_atacado", "atacado", "Painel inicial"),
    Tela("lista_atacado", "/atacado_formularios", "atacado", "Lista"),
    Tela("form_novo", "/atacado_formularios/new", "atacado", "Formulário"),
    Tela("form_edicao", f"/atacado_formularios/{FORM_ID}", "atacado", "Formulário"),
    Tela("central_engenharia", "/central_engenharia", "engenharia", "Painel inicial"),
    Tela("lista_engenharia", "/engenharia_formularios", "engenharia", "Lista"),
    Tela("form_engenharia", f"/engenharia_formularios/{FORM_ID}", "engenharia", "Formulário · Detalhe"),
    Tela("erro_404", "/pagina-que-nao-existe", "atacado", "Página de erro"),
    # Linha do tempo (fluxo/): mesma tela para os dois perfis
    Tela("processo_atacado", f"/processos/{FORM_ID}", "atacado", "Detalhe"),
    Tela("processo_engenharia", f"/processos/{FORM_ID}", "engenharia", "Detalhe"),
    Tela("indicadores", "/indicadores", "engenharia", "Painel"),
    Tela("alertas", "/alertas", "atacado", "Lista"),
)


def cookie_de_sessao(perfil: str | None) -> list[dict]:
    """Cookie 'session' assinado para o perfil (lista vazia para anônimo)."""
    if perfil is None:
        return []
    sys.path.insert(0, str(RAIZ))
    from app import create_app  # import tardio: só quando há sessão

    app = create_app()
    valor = app.session_interface.get_signing_serializer(app).dumps(dict(USUARIOS[perfil]))
    host = BASE_URL.split("://", 1)[1].split("/", 1)[0].split(":")[0]
    return [{"name": "session", "value": valor, "domain": host, "path": "/"}]


def abrir_navegador(playwright):
    """Chrome instalado (ou Edge), sem baixar navegador próprio."""
    for canal in ("chrome", "msedge"):
        try:
            return playwright.chromium.launch(channel=canal)
        except Exception:  # canal indisponível nesta máquina
            continue
    return playwright.chromium.launch()
