"""Verificações automáticas do controle de qualidade da repaginada visual.

Uso (com a aplicação no ar em QA_BASE_URL, padrão http://127.0.0.1:5000):
    python tools/qa/verificacoes.py

Saída: tools/qa/saida/verificacoes.json e um resumo no terminal.
Cada verificação usa os números do prompt (seção controle_de_qualidade).
"""
from __future__ import annotations

import json


from playwright.sync_api import TimeoutError as PlaywrightTimeout
from playwright.sync_api import sync_playwright

from comum import BASE_URL, LARGURAS, SAIDA, TELAS, abrir_navegador, cookie_de_sessao

# ---------------------------------------------------------------------------
# Scripts executados na página
# ---------------------------------------------------------------------------
JS_LAYOUT = """() => ({
  scrollWidth: document.documentElement.scrollWidth,
  innerWidth: window.innerWidth,
})"""

# Texto visível abaixo de 14 px (HTML e SVG, considerando a escala do viewBox)
JS_TEXTO = """() => {
  const ruins = [];
  const visivel = (el) => {
    if (el.closest('.sr-only, template, [hidden], .tooltip')) return false;
    const r = el.getClientRects();
    if (!r.length) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none';
  };
  const andar = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (andar.nextNode()) {
    const no = andar.currentNode;
    if (!no.textContent.trim()) continue;
    const el = no.parentElement;
    if (!el || !visivel(el)) continue;
    let px = parseFloat(getComputedStyle(el).fontSize);
    if (el instanceof SVGElement) {
      const m = el.getScreenCTM();
      if (m) px = px * Math.abs(m.a);
    }
    if (px < 13.95) ruins.push({texto: no.textContent.trim().slice(0, 40), px: +px.toFixed(1), tag: el.tagName});
  }
  return ruins.slice(0, 15);
}"""

# Contraste de texto (4,5:1; 3:1 para texto grande) e bordas de campo (3:1)
JS_CONTRASTE = """() => {
  const cor = (s) => {
    const m = s && s.match(/rgba?\\(([^)]+)\\)/);
    if (!m) return null;
    const p = m[1].split(',').map((x) => parseFloat(x));
    return {rgb: p.slice(0, 3), a: p.length > 3 ? p[3] : 1};
  };
  const lum = ([r, g, b]) => {
    const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  };
  const razao = (a, b) => { const [l1, l2] = [lum(a), lum(b)].sort((x, y) => y - x); return (l1 + 0.05) / (l2 + 0.05); };
  const fundo = (el) => {
    for (let e = el; e; e = e.parentElement) {
      const c = cor(getComputedStyle(e).backgroundColor);
      if (c && c.a > 0.5) return c.rgb;
    }
    return [255, 255, 255];
  };
  const ruins = [];
  const vistos = new Set();
  const andar = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (andar.nextNode()) {
    const no = andar.currentNode;
    if (!no.textContent.trim()) continue;
    const el = no.parentElement;
    if (!el || vistos.has(el) || el.closest('.sr-only, template, [hidden], [aria-hidden="true"]')) continue;
    if (!el.getClientRects().length) continue;
    vistos.add(el);
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0) continue;
    const c = cor(el instanceof SVGElement ? cs.fill : cs.color);
    if (!c) continue;
    const px = parseFloat(cs.fontSize), peso = parseInt(cs.fontWeight, 10) || 400;
    const grande = px >= 24 || (px >= 18.66 && peso >= 600);
    const r = razao(c.rgb, fundo(el));
    if (r < (grande ? 3 : 4.5) - 0.01) ruins.push({texto: no.textContent.trim().slice(0, 40), razao: +r.toFixed(2)});
  }
  document.querySelectorAll('input.control, select.control, textarea.control, .ms-control').forEach((el) => {
    if (!el.getClientRects().length || el.readOnly || el.disabled || el.closest('.ro')) return;
    const b = cor(getComputedStyle(el).borderTopColor);
    if (b && razao(b.rgb, fundo(el.parentElement)) < 3) ruins.push({campo: el.id || el.name || el.className, borda: true});
  });
  return ruins.slice(0, 15);
}"""

JS_TOKENS = """async () => {
  await Promise.all([document.fonts.load('600 16px Inter'), document.fonts.load('300 64px "Inter Display"')]);
  return {
    primaria: getComputedStyle(document.documentElement).getPropertyValue('--c-primary').trim().toLowerCase(),
    inter: document.fonts.check('600 16px Inter'),
    display: document.fonts.check('300 64px "Inter Display"'),
    externas: performance.getEntriesByType('resource').map((r) => r.name).filter((n) => !n.startsWith(location.origin)),
  };
}"""

JS_ENTRADAS = """() => {
  const vh = window.innerHeight;
  return [...document.querySelectorAll('[data-reveal], [data-split] .w')]
    .filter((el) => { const r = el.getBoundingClientRect(); return r.height > 0 && r.bottom > 0 && r.top < vh; })
    .filter((el) => parseFloat(getComputedStyle(el).opacity) < 0.999)
    .map((el) => el.className || el.tagName).slice(0, 10);
}"""

# Só animações CSS (laços, gestos, contagem); as transições de entrada, que duram
# menos de 1 s e terminam sozinhas, ficam fora da conta
JS_ANIMACOES = """() => document.getAnimations().filter((a) => a.playState === 'running' && a instanceof CSSAnimation).length"""

JS_FPS = """() => new Promise((resolve) => {
  const quadros = []; const longas = [];
  let ultimo = performance.now(); const inicio = ultimo;
  try {
    new PerformanceObserver((lista) => lista.getEntries().forEach((e) => longas.push(Math.round(e.duration))))
      .observe({type: 'longtask', buffered: false});
  } catch (e) { /* sem suporte */ }
  const passo = (agora) => {
    quadros.push(agora - ultimo); ultimo = agora;
    if (agora - inicio < 5000) requestAnimationFrame(passo);
    else resolve({fps: quadros.length / ((agora - inicio) / 1000), maior: Math.max(...quadros.slice(1)), longas});
  };
  requestAnimationFrame(passo);
})"""


# ---------------------------------------------------------------------------
def nova_pagina(navegador, tela, largura, altura, **opcoes):
    contexto = navegador.new_context(viewport={"width": largura, "height": altura}, **opcoes)
    contexto.add_cookies(cookie_de_sessao(tela.perfil))
    pagina = contexto.new_page()
    erros: list[str] = []

    def no_console(m):
        # O status 404 do próprio documento é o esperado na página de erro
        if m.type in ("error", "warning") and not (tela.nome == "erro_404" and "404" in m.text and m.location.get("url", "").endswith(tela.caminho)):
            erros.append(f"{m.type}: {m.text}")
    pagina.on("console", no_console)
    pagina.on("pageerror", lambda e: erros.append(f"pageerror: {e}"))
    falhas: list[str] = []
    pagina.on("response", lambda r: falhas.append(f"{r.status} {r.url}") if r.status >= 400 and r.request.resource_type != "document" else None)
    return contexto, pagina, erros, falhas


def abrir(pagina, caminho):
    try:
        pagina.goto(BASE_URL + caminho, wait_until="load", timeout=20000)
    except PlaywrightTimeout:
        pass
    esperar_motor(pagina)


def esperar_motor(pagina):
    """O motor de movimento liga depois das fontes (html.is-ready)."""
    try:
        pagina.wait_for_function("document.documentElement.classList.contains('is-ready')", timeout=8000)
    except PlaywrightTimeout:
        pass


def verificar_telas(navegador) -> list[dict]:
    resultados = []
    for tela in TELAS:
        for rotulo, (largura, altura) in LARGURAS.items():
            contexto, pagina, erros, falhas = nova_pagina(navegador, tela, largura, altura)
            abrir(pagina, tela.caminho)
            estatica = pagina.evaluate("() => document.querySelector('#conteudo')?.dataset.motion === 'static'")
            entradas_0 = pagina.evaluate(JS_ENTRADAS) if estatica else []
            pagina.wait_for_timeout(4000)
            layout = pagina.evaluate(JS_LAYOUT)
            r = {
                "tela": tela.nome, "largura": rotulo,
                "rolagem_lateral": layout["scrollWidth"] <= layout["innerWidth"],
                "texto_pequeno": pagina.evaluate(JS_TEXTO),
                "contraste": pagina.evaluate(JS_CONTRASTE),
                "entradas_4000ms": pagina.evaluate(JS_ENTRADAS),
                "entradas_static_0ms": entradas_0,
            }
            if rotulo == "1366":
                r["tokens"] = pagina.evaluate(JS_TOKENS)
                r["teclado"] = verificar_teclado(pagina)
            r["console"] = list(erros)
            r["rede_falhas"] = list(falhas)
            resultados.append(r)
            contexto.close()
        print(f"ok  {tela.nome}")
    return resultados


def verificar_teclado(pagina) -> dict:
    """Tab percorre os interativos; cada um mostra contorno de pelo menos 2 px."""
    positivo = pagina.evaluate("() => [...document.querySelectorAll('[tabindex]')].filter(e => e.tabIndex > 0).length")
    sem_contorno, vistos = [], 0
    pagina.mouse.click(1, 1)
    for _ in range(40):
        pagina.keyboard.press("Tab")
        info = pagina.evaluate("""() => {
          const e = document.activeElement; if (!e || e === document.body) return null;
          const cs = getComputedStyle(e);
          return {id: e.id || e.textContent.trim().slice(0, 24) || e.tagName, w: parseFloat(cs.outlineWidth), s: cs.outlineStyle};
        }""")
        if not info:
            continue
        vistos += 1
        if info["s"] == "none" or info["w"] < 2:
            sem_contorno.append(info["id"])
    return {"focaveis_visitados": vistos, "sem_contorno": sem_contorno[:10], "tabindex_positivo": positivo}


def verificar_movimento(navegador) -> dict:
    painel = next(t for t in TELAS if t.nome == "central_atacado")
    out = {}

    # Movimento reduzido: nada rodando, tudo visível em 1200 ms, contadores no valor final
    contexto, pagina, *_ = nova_pagina(navegador, painel, 1366, 768, reduced_motion="reduce")
    abrir(pagina, painel.caminho)
    pagina.wait_for_timeout(1200)
    out["reduzido"] = {
        "animacoes_rodando": pagina.evaluate(JS_ANIMACOES),
        "invisiveis_1200ms": pagina.evaluate(JS_ENTRADAS),
        "contadores_finais": pagina.evaluate("() => [...document.querySelectorAll('[data-count]')].every(e => !e.classList.contains('is-counting'))"),
    }
    contexto.close()

    # Pausa: pausa no quadro seguinte, persiste ao recarregar e retoma os ciclos
    contexto, pagina, *_ = nova_pagina(navegador, painel, 1366, 768)
    abrir(pagina, painel.caminho)
    pagina.wait_for_timeout(1500)
    antes = pagina.evaluate(JS_ANIMACOES)
    pagina.click('[data-action="motion"]')
    pagina.wait_for_timeout(50)
    pausado = pagina.evaluate(JS_ANIMACOES)
    pagina.reload(wait_until="load")
    esperar_motor(pagina)
    pagina.wait_for_timeout(300)
    persistiu = pagina.evaluate("() => document.documentElement.classList.contains('is-paused')")
    rodando_apos_recarregar = pagina.evaluate(JS_ANIMACOES)
    pagina.click('[data-action="motion"]')
    pagina.wait_for_timeout(200)
    retomou = pagina.evaluate(JS_ANIMACOES)
    out["pausa"] = {"rodando_antes": antes, "rodando_pausado": pausado, "persistiu": persistiu,
                    "rodando_apos_recarregar": rodando_apos_recarregar, "rodando_apos_retomar": retomou}

    # Desempenho: CPU 4× mais lenta, rAF por 5 s
    cdp = contexto.new_cdp_session(pagina)
    cdp.send("Emulation.setCPUThrottlingRate", {"rate": 4})
    pagina.reload(wait_until="load")
    esperar_motor(pagina)
    pagina.wait_for_timeout(2500)
    fps = pagina.evaluate(JS_FPS)
    out["desempenho"] = {"fps_medio": round(fps["fps"], 1), "maior_quadro_ms": round(fps["maior"], 1),
                         "tarefas_longas": fps["longas"]}
    contexto.close()
    return out


def verificar_formularios(navegador) -> dict:
    out = {}
    # Envio com erro: resumo visível e com foco
    tela = next(t for t in TELAS if t.nome == "form_novo")
    contexto, pagina, *_ = nova_pagina(navegador, tela, 1366, 768)
    abrir(pagina, tela.caminho)
    pagina.wait_for_timeout(800)
    pagina.click("#btnFinish")
    pagina.wait_for_timeout(300)
    out["erro_resumo"] = pagina.evaluate("""() => ({
      visivel: !document.getElementById('valBox').hidden,
      foco: document.activeElement === document.getElementById('valBox'),
      titulo: document.getElementById('valTitle').textContent,
    })""")
    contexto.close()

    # Envio válido com data-busy: estado ocupado em até 100 ms. Credenciais
    # fictícias; um ouvinte de submit na window (roda depois do ui.js, que
    # escuta no document) cancela a navegação, então nada chega ao servidor.
    tela = next(t for t in TELAS if t.nome == "login")
    contexto, pagina, *_ = nova_pagina(navegador, tela, 1366, 768)
    abrir(pagina, tela.caminho)
    pagina.wait_for_timeout(800)
    pagina.fill("#email", "qa@exemplo.invalid")
    pagina.fill("#password", "senha-ficticia")
    pagina.evaluate("""() => {
      const b = document.getElementById('btnLogin');
      window.__busyMs = null;
      new MutationObserver(() => {
        if (window.__busyMs === null && b.getAttribute('aria-busy') === 'true') window.__busyMs = performance.now() - window.__t0;
      }).observe(b, {attributes: true});
      b.addEventListener('click', () => { window.__t0 = performance.now(); }, {capture: true});
      window.addEventListener('submit', (e) => e.preventDefault());
    }""")
    pagina.click("#btnLogin", no_wait_after=True, timeout=10000)
    pagina.wait_for_timeout(300)
    out["envio_ocupado"] = pagina.evaluate("""() => ({
      aria_busy: document.getElementById('btnLogin').getAttribute('aria-busy'),
      rotulo: document.querySelector('#btnLogin .button__label').textContent,
      ms: window.__busyMs === null ? null : Math.round(window.__busyMs),
      topo_ocupado: document.documentElement.classList.contains('is-busy'),
    })""")
    contexto.close()
    return out


def main() -> None:
    SAIDA.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        navegador = abrir_navegador(p)
        resultado = {}
        # Cada seção é gravada assim que termina (uma falha posterior não perde o resto)
        for chave, funcao in (("telas", verificar_telas), ("movimento", verificar_movimento),
                              ("formularios", verificar_formularios)):
            resultado[chave] = funcao(navegador)
            (SAIDA / "verificacoes.json").write_text(json.dumps(resultado, ensure_ascii=False, indent=2), encoding="utf-8")
        navegador.close()

    falhas = 0
    for r in resultado["telas"]:
        problemas = [k for k in ("texto_pequeno", "contraste", "entradas_4000ms", "entradas_static_0ms", "console", "rede_falhas") if r.get(k)]
        if not r["rolagem_lateral"]:
            problemas.append("rolagem_lateral")
        if "tokens" in r:
            t = r["tokens"]
            if t["primaria"] != "#660099" or not t["inter"] or not t["display"] or t["externas"]:
                problemas.append("tokens")
            if r["teclado"]["sem_contorno"] or r["teclado"]["tabindex_positivo"]:
                problemas.append("teclado")
        falhas += bool(problemas)
        print(f"{'FALHA' if problemas else 'ok   '} {r['tela']:<20} {r['largura']:>5}  {', '.join(problemas)}")
    print(json.dumps({"movimento": resultado["movimento"], "formularios": resultado["formularios"]}, ensure_ascii=False, indent=2))
    print(f"\nTelas com problema: {falhas} de {len(resultado['telas'])}")


if __name__ == "__main__":
    main()
