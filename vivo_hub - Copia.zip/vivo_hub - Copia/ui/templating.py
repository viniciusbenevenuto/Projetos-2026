"""Auxiliares de template da repaginada visual.

- flash_variant(): mapeia a categoria de flash() para a variante da mensagem
  (sucesso, informação, aviso, erro), com ícone, papel ARIA e palavra de
  gravidade. Categorias desconhecidas viram informação e vão para o log.
- Páginas de erro 404 e 500 no padrão das faixas escuras.
"""
from __future__ import annotations

import logging

from flask import Flask, render_template

LOG = logging.getLogger(__name__)

_VARIANTES = {
    "success": {"variante": "success", "icone": "circle-check", "papel": "status", "gravidade": ""},
    "info": {"variante": "info", "icone": "info", "papel": "status", "gravidade": ""},
    "warning": {"variante": "warning", "icone": "triangle-alert", "papel": "alert", "gravidade": "Atenção:"},
    "error": {"variante": "error", "icone": "circle-alert", "papel": "alert", "gravidade": "Erro:"},
}
_ALIASES = {"message": "info", "danger": "error"}


def flash_variant(categoria: str) -> dict:
    """Variante visual de uma categoria de flash()."""
    chave = _ALIASES.get(categoria, categoria)
    if chave not in _VARIANTES:
        LOG.warning("Categoria de flash desconhecida '%s' exibida como informação", categoria)
        chave = "info"
    return _VARIANTES[chave]


def register_ui(app: Flask) -> None:
    """Registra os auxiliares no Jinja e as páginas de erro."""
    app.jinja_env.globals["flash_variant"] = flash_variant

    @app.errorhandler(404)
    def pagina_nao_encontrada(_erro):
        return render_template("erro.html", codigo=404), 404

    @app.errorhandler(500)
    def erro_interno(_erro):
        return render_template("erro.html", codigo=500), 500
