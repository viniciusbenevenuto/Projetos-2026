"""Ícones Lucide inline e auxiliares de movimento para os templates Jinja.

Lê os SVGs de static/vendor/lucide uma única vez e devolve a marcação pronta,
com pathLength="1" quando o ícone se desenha ou ganha o cometa. Registra também
o filtro que separa títulos em palavras e a grade de células dos indicadores.
"""
from __future__ import annotations

import logging
import math
import re
from pathlib import Path

from flask import Flask
from markupsafe import Markup, escape

LOG = logging.getLogger(__name__)

SVG_INNER = re.compile(r"<svg[^>]*>(.*?)</svg>", re.S)
SHAPE = re.compile(r"<(path|circle|rect|line|polyline|polygon|ellipse)\b([^>]*?)\s*/>")
MAX_CELLS = 64  # 4 linhas de 16 cabem no viewBox 440 × 104 da representação


class LucideRegistry:
    """Ícones do pacote lucide-static@1.52.0 copiados para static/vendor/lucide."""

    def __init__(self, icons_dir: Path) -> None:
        if not icons_dir.is_dir():
            raise FileNotFoundError(f"Pasta de ícones inexistente: {icons_dir}")
        self.icons_dir = icons_dir
        self._cache: dict[str, tuple[str, ...]] = {}

    def shapes(self, name: str) -> tuple[str, ...]:
        """Formas internas do SVG (path, circle, rect...), lidas uma vez e guardadas."""
        if name not in self._cache:
            source = self.icons_dir / f"{name}.svg"
            if not source.is_file():
                raise FileNotFoundError(f"Ícone Lucide inexistente: {name}")
            inner = SVG_INNER.search(source.read_text(encoding="utf-8"))
            if inner is None:
                raise ValueError(f"SVG inválido: {source}")
            self._cache[name] = tuple(f"<{tag}{attrs}/>" for tag, attrs in SHAPE.findall(inner.group(1)))
            LOG.debug("Ícone carregado: %s", name)
        return self._cache[name]

    def render(self, name: str, cls: str = "ui-icon", *, draw: bool = False, layered: bool = False) -> Markup:
        """SVG inline decorativo, com os atributos de traço do Lucide (o CSS das classes prevalece).

        draw: o ícone se desenha na entrada (classe icon--draw no SVG).
        layered: acrescenta a camada do cometa (gesto trace e botão ocupado).
        """
        shapes = self.shapes(name)
        classes = cls.split()
        if draw and "icon--draw" not in classes:
            classes.append("icon--draw")
        cls = " ".join(classes)
        if draw or layered:
            ink = "".join(shape.replace("/>", ' pathLength="1"/>') for shape in shapes)
            body = f'<g class="icon__ink">{ink}</g>'
            if layered:
                body += f'<g class="icon__comet">{ink}</g>'
        else:
            body = "".join(shapes)
        return Markup(
            f'<svg class="{escape(cls)}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
            f'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">{body}</svg>'
        )


def split_words(text: str) -> Markup:
    """Título palavra por palavra (só texto puro); o espaço inseparável mantém pares juntos."""
    words = [word for word in str(text).strip().split(" ") if word]
    return Markup(" ".join(f'<span class="w">{escape(word)}</span>' for word in words))


def cell_grid(count: int, cols: int = 16, size: int = 20, gap: int = 8) -> Markup:
    """Grade de células, uma por unidade real; data-p ordena a onda na diagonal."""
    if not 0 < count <= MAX_CELLS:
        raise ValueError(f"A grade aceita de 1 a {MAX_CELLS} células; recebeu {count}")
    cols = min(cols, count)
    rows = math.ceil(count / cols)
    span = max((cols - 1) + (rows - 1) * 0.5, 1)
    base: list[str] = []
    ink: list[str] = []
    for n in range(count):
        col, row = n % cols, n // cols
        x, y = col * (size + gap), row * (size + gap)
        position = (col + row * 0.5) / span
        base.append(f'<rect class="cell-base" x="{x}" y="{y}" width="{size}" height="{size}" rx="3"/>')
        ink.append(
            f'<rect class="cell-ink" data-p="{position:.4f}" x="{x}" y="{y}" width="{size}" height="{size}" rx="3"/>'
        )
    return Markup(f'<g class="cells__base">{"".join(base)}</g><g class="cells__ink">{"".join(ink)}</g>')


def init_ui(app: Flask) -> None:
    """Registra ícone, filtro e grade no ambiente Jinja da aplicação."""
    if app.static_folder is None:
        raise RuntimeError("A aplicação não tem pasta de estáticos configurada")
    registry = LucideRegistry(Path(app.static_folder) / "vendor" / "lucide")
    app.jinja_env.globals["icon"] = registry.render
    app.jinja_env.globals["cell_grid"] = cell_grid
    app.jinja_env.filters["split_words"] = split_words
    LOG.info("Interface: ícones Lucide e auxiliares de movimento registrados")
