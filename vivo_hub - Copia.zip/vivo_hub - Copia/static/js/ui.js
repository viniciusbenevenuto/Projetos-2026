/* ==========================================================================
   ui.js · PTI Automatizado
   1 Dica das siglas · 2 Estado ocupado · 3 Mensagens · 4 Início
   5 Menu compacto · 6 Confirmação em modal · 7 Notificação do cliente · 8 Copiar
   O menu compacto e o modal seguem a especificação dos componentes 1 e 14.
   ========================================================================== */
(() => {
  'use strict';

  const root = document.documentElement;
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

  const announce = (message) => {
    const region = $('#announcer');
    if (region) region.textContent = message;
  };

  const headerHeight = () => {
    const topbar = $('#topbar');
    return topbar ? topbar.getBoundingClientRect().height : 0;
  };

  /* 1 Dica das siglas: definição ao passar o mouse ou focar (idêntica à apresentação) */
  class TermTooltip {
    constructor(element) {
      this.element = element;
      this.current = null;
      document.addEventListener('pointerover', (event) => {
        const term = event.target instanceof Element ? event.target.closest('.term') : null;
        if (term) this.show(term);
      });
      document.addEventListener('pointerout', (event) => {
        const term = event.target instanceof Element ? event.target.closest('.term') : null;
        if (term && !term.contains(event.relatedTarget)) this.hide(term);
      });
      document.addEventListener('focusin', (event) => {
        if (event.target instanceof Element && event.target.classList.contains('term')) this.show(event.target);
      });
      document.addEventListener('focusout', (event) => {
        if (event.target instanceof Element && event.target.classList.contains('term')) this.hide(event.target);
      });
      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') this.hide();
      });
      window.addEventListener('scroll', () => this.hide(), { passive: true });
    }

    show(term) {
      if (this.current && this.current !== term) this.current.removeAttribute('aria-describedby');
      this.current = term;
      const label = document.createElement('span');
      label.className = 'tooltip__term';
      label.setAttribute('aria-hidden', 'true');
      label.textContent = term.textContent;
      this.element.replaceChildren(label, document.createTextNode(term.dataset.def || ''));
      term.setAttribute('aria-describedby', this.element.id);

      const anchor = term.getBoundingClientRect();
      const tip = this.element.getBoundingClientRect();
      const x = clamp(anchor.left + anchor.width / 2 - tip.width / 2, 16, window.innerWidth - tip.width - 16);
      let y = anchor.top - tip.height - 10;
      if (y < headerHeight() + 8) y = anchor.bottom + 10;
      this.element.style.setProperty('--tip-x', `${Math.round(x)}px`);
      this.element.style.setProperty('--tip-y', `${Math.round(y)}px`);
      this.element.classList.add('is-visible');
    }

    hide(term) {
      if (term && term !== this.current) return;
      if (this.current) this.current.removeAttribute('aria-describedby');
      this.current = null;
      this.element.classList.remove('is-visible');
    }
  }

  /* 2 Estado ocupado ---------------------------------------------------------------
     Só durante requisições reais: o botão mostra o gerúndio e o cometa no ícone,
     e a barra superior mostra o segmento de atividade (html.is-busy). */
  class Busy {
    constructor() {
      this.pending = 0;
      document.addEventListener('submit', (event) => this.onSubmit(event));
      window.addEventListener('pageshow', (event) => { if (event.persisted) this.reset(); });
    }

    onSubmit(event) {
      const form = event.target;
      if (!(form instanceof HTMLFormElement) || !form.hasAttribute('data-busy') || event.defaultPrevented) return;
      const submitter = event.submitter instanceof HTMLButtonElement ? event.submitter : $('button[type="submit"]', form);
      this.start(submitter);
    }

    start(button) {
      this.pending += 1;
      root.classList.add('is-busy');
      if (!button || button.getAttribute('aria-busy') === 'true') return;
      const label = $('.button__label', button);
      const busyLabel = button.dataset.busyLabel;
      button.style.setProperty('min-width', `${Math.ceil(button.getBoundingClientRect().width)}px`);
      if (label && busyLabel) {
        button.dataset.idleLabel = label.textContent;
        label.textContent = busyLabel;
        announce(busyLabel);
      }
      button.setAttribute('aria-busy', 'true');
      // Desabilitar depois do envio: antes disso, o navegador cancelaria a submissão
      window.setTimeout(() => { button.disabled = true; }, 0);
    }

    stop(button) {
      this.pending = Math.max(0, this.pending - 1);
      if (!this.pending) root.classList.remove('is-busy');
      if (button) this.restore(button);
    }

    restore(button) {
      const label = $('.button__label', button);
      if (label && button.dataset.idleLabel) label.textContent = button.dataset.idleLabel;
      delete button.dataset.idleLabel;
      button.removeAttribute('aria-busy');
      button.disabled = false;
      button.style.removeProperty('min-width');
    }

    /** Envolve uma requisição existente sem alterar o resultado: PTI.busy(fetch(...), botão). */
    wrap(promise, button = null) {
      this.start(button);
      return Promise.resolve(promise).finally(() => this.stop(button));
    }

    reset() {
      this.pending = 0;
      root.classList.remove('is-busy');
      $$('button[aria-busy="true"]').forEach((button) => this.restore(button));
    }
  }

  /* 3 Mensagens: saem com opacidade em 240 ms; fechar devolve o foco ao conteúdo -------- */
  const leave = (message) => {
    const remove = () => message.remove();
    message.classList.add('is-leaving');
    message.addEventListener('transitionend', remove, { once: true });
    window.setTimeout(remove, 400); // garantia, caso a transição não dispare
  };

  const bindMessages = () => {
    document.addEventListener('click', (event) => {
      const close = event.target instanceof Element ? event.target.closest('[data-action="dismiss"]') : null;
      const message = close ? close.closest('.msg') : null;
      if (!message) return;
      leave(message);
      const main = $('#conteudo');
      if (main) main.focus({ preventScroll: true });
    });

    // Notificação de sucesso ou informação: sai quando o temporizador de 6 s termina
    document.addEventListener('animationend', (event) => {
      if (!(event.target instanceof Element) || event.animationName !== 'toast-timer') return;
      const toast = event.target.closest('.toast');
      if (toast) leave(toast);
    });
  };

  /* 5 Menu compacto (componente 1) ----------------------------------------------------
     Abaixo de 1024 px os links da barra vão para o botão "Menu". Abre e fecha com
     opacidade (160 ms linear, no CSS); Esc fecha e devolve o foco ao botão. */
  class CompactMenu {
    constructor(button) {
      this.button = button;
      this.panel = document.getElementById(button.getAttribute('aria-controls'));
      if (!this.panel) return;
      button.addEventListener('click', () => (this.isOpen ? this.close() : this.open()));
      document.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape' || !this.isOpen) return;
        this.close();
        this.button.focus();
      });
      document.addEventListener('click', (event) => {
        if (!this.isOpen || this.panel.contains(event.target) || this.button.contains(event.target)) return;
        this.close();
      });
      window.addEventListener('resize', () => { if (this.isOpen && window.innerWidth >= 1024) this.close(); });
    }

    get isOpen() { return this.button.getAttribute('aria-expanded') === 'true'; }

    open() {
      this.panel.hidden = false;
      this.button.setAttribute('aria-expanded', 'true');
      requestAnimationFrame(() => this.panel.classList.add('is-open'));
      const first = $('a, button', this.panel);
      if (first) first.focus();
    }

    close() {
      this.button.setAttribute('aria-expanded', 'false');
      this.panel.classList.remove('is-open');
      window.setTimeout(() => { if (!this.isOpen) this.panel.hidden = true; }, 170);
    }
  }

  /* 6 Confirmação em modal (componente 14) ----------------------------------------------
     Substitui o confirm() nativo. Formulários com data-confirm="Mensagem" pedem
     confirmação antes do envio; o código de negócio usa PTI.confirm(mensagem). */
  class ConfirmDialog {
    constructor(dialog) {
      this.dialog = dialog;
      this.title = $('[data-confirm-title]', dialog);
      this.text = $('[data-confirm-text]', dialog);
      this.ok = $('[data-confirm-ok]', dialog);
      this.okLabel = $('.button__label', this.ok);
      this.resolve = null;
      this.trigger = null;
      // A resposta sai no próprio clique; o evento "close" (Esc) fica como reserva,
      // porque o navegador pode adiá-lo com a aba oculta.
      this.ok.addEventListener('click', () => this.answer(true));
      $$('[data-action="close-dialog"]', dialog).forEach((button) => {
        button.addEventListener('click', () => this.answer(false));
      });
      // Clique no fundo: o painel ocupa todo o <dialog>, então o alvo é o próprio dialog
      dialog.addEventListener('click', (event) => { if (event.target === dialog) this.answer(false); });
      dialog.addEventListener('close', () => this.finish(dialog.returnValue === 'ok'));
    }

    ask(message, { title = 'Confirmar', confirmLabel = 'Confirmar' } = {}) {
      if (this.resolve) this.finish(false);
      this.trigger = document.activeElement;
      this.title.textContent = title;
      this.text.textContent = message;
      this.okLabel.textContent = confirmLabel;
      this.dialog.returnValue = '';
      this.dialog.showModal();   // o foco vai para o primeiro elemento (fechar)
      return new Promise((resolve) => { this.resolve = resolve; });
    }

    answer(confirmed) {
      this.finish(confirmed);
      if (this.dialog.open) this.dialog.close(confirmed ? 'ok' : 'cancel');
    }

    finish(confirmed) {
      const resolve = this.resolve;
      this.resolve = null;
      if (this.trigger && typeof this.trigger.focus === 'function') this.trigger.focus({ preventScroll: true });
      if (resolve) resolve(confirmed);
    }
  }

  const bindConfirm = (dialog) => {
    // Fase de captura: roda antes do estado ocupado, que só liga em envio não cancelado
    document.addEventListener('submit', (event) => {
      const form = event.target;
      if (!(form instanceof HTMLFormElement) || !form.dataset.confirm) return;
      if (form.dataset.confirmed === '1') { delete form.dataset.confirmed; return; }
      event.preventDefault();
      const submitter = event.submitter instanceof HTMLElement && event.submitter.form === form ? event.submitter : null;
      dialog.ask(form.dataset.confirm, {
        title: form.dataset.confirmTitle || 'Confirmar',
        confirmLabel: form.dataset.confirmOk || 'Confirmar',
      }).then((confirmed) => {
        if (!confirmed) return;
        form.dataset.confirmed = '1';
        if (submitter) form.requestSubmit(submitter);
        else form.requestSubmit();
      });
    }, true);
  };

  /* 7 Notificação do cliente (componente 9) ---------------------------------------------
     Resultado de ação sem recarregar a página. Sucesso e informação fecham sozinhos
     após 6 s (temporizador no CSS); aviso e erro só pela pessoa. */
  const STATUS = {
    success: { icon: 'circle-check', role: 'status' },
    info: { icon: 'info', role: 'status' },
    warning: { icon: 'triangle-alert', role: 'alert', lead: 'Atenção:' },
    error: { icon: 'circle-alert', role: 'alert', lead: 'Erro:' },
  };

  const iconNode = (name) => {
    const template = $(`template[data-icon="${name}"]`);
    return template ? template.content.firstElementChild.cloneNode(true) : document.createElement('span');
  };

  const toast = (text, { variant = 'success', lead = '' } = {}) => {
    const kind = STATUS[variant] ? variant : 'info';
    const spec = STATUS[kind];
    const message = document.createElement('div');
    message.className = `msg msg--${kind} toast`;
    message.setAttribute('role', spec.role);
    message.setAttribute('data-enter', '');
    const icon = iconNode(spec.icon);
    icon.classList.add('msg__icon');
    const body = document.createElement('p');
    body.className = 'msg__text';
    const strong = lead || spec.lead;
    if (strong) {
      const b = document.createElement('strong');
      b.textContent = `${strong} `;
      body.append(b);
    }
    body.append(document.createTextNode(text));
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'icon-button msg__close';
    close.dataset.action = 'dismiss';
    close.setAttribute('aria-label', 'Fechar mensagem');
    close.title = 'Fechar mensagem';
    close.append(iconNode('x'));
    message.append(icon, body, close);
    // Temporizador só quando a notificação pode fechar sozinha e há movimento
    const motionOk = !root.classList.contains('is-paused') && !root.classList.contains('is-reduced');
    if ((kind === 'success' || kind === 'info') && motionOk) {
      const timer = document.createElement('span');
      timer.className = 'toast__timer';
      timer.append(document.createElement('span'));
      message.append(timer);
    }
    $$('.toast').forEach((old) => leave(old));
    document.body.append(message);
    announce(`${strong ? `${strong} ` : ''}${text}`);
    return message;
  };

  /* 8 Copiar texto: API moderna e, quando indisponível (acesso pelo IP da rede,
     sem HTTPS), o método clássico com seleção de texto. */
  const copy = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      const area = document.createElement('textarea');
      area.value = text;
      area.setAttribute('readonly', '');
      area.className = 'sr-only';
      document.body.append(area);
      area.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch { ok = false; }
      area.remove();
      return ok;
    }
  };

  /* 4 Início ------------------------------------------------------------------------- */
  const tooltip = $('#tooltip');
  if (tooltip) new TermTooltip(tooltip);
  const busy = new Busy();
  bindMessages();
  $$('[data-action="menu"]').forEach((button) => new CompactMenu(button));
  const confirmElement = $('#confirm-dialog');
  const confirmDialog = confirmElement ? new ConfirmDialog(confirmElement) : null;
  if (confirmDialog) bindConfirm(confirmDialog);

  // Página que volta do servidor com aviso ou erro: a mensagem recebe o foco
  const alerta = $('.messages .msg[role="alert"]');
  if (alerta) {
    alerta.setAttribute('tabindex', '-1');
    alerta.focus();
  }

  window.PTI = Object.assign(window.PTI || {}, {
    busy: (promise, button) => busy.wrap(promise, button),
    confirm: (message, options) => (confirmDialog
      ? confirmDialog.ask(message, options)
      : Promise.resolve(window.confirm(message))),
    toast,
    icon: iconNode,
    announce,
    copy,
  });
})();
