# Linha do tempo do PTI AUTOMATIZADO

Diagnóstico do fluxo atual, fluxo proposto, modelo de dados e plano de
implementação. O código está em `fluxo/` (regras e dados), `routes/processos.py`
(telas e ações) e `templates/processo.html`, `indicadores.html`, `alertas.html`.

## 1. Diagnóstico (antes)

### 1.1 Como os processos são armazenados
Cada Pré-PTI é uma linha de `atacado_forms`. Uma "nova versão" é outra linha,
com `parent_id` apontando para a raiz e `version` incrementado. O estado do
processo era só a coluna `status` (texto livre) e as datas `created_at` e
`updated_at`. Não existia tabela de histórico, de responsáveis ou de prazos.

### 1.2 Status existentes
| Status | Quem gravava | Onde |
|---|---|---|
| `rascunho` | Atacado ("Salvar rascunho") e toda nova versão | `atacado.form_create`, `form_update`, `form_new_version` |
| `enviado` | Atacado ("Finalizar") | `atacado.form_create`, `form_update` |
| `aprovado` | Engenharia ("Aprovar", na lista) | `engenharia.validar` |
| `reprovado` | Engenharia ("Reprovar", na lista) | `engenharia.reprovar` |
| `em revisão` | ninguém — aparecia só em filtros e contadores | — |

### 1.3 Etapas da Engenharia
Validar os dados técnicos (Dados VIVO, SBC por capacidade, Mask, dimensionamento),
gerar o PTI em Excel (com reserva no IPAM), enviar o PTI à operadora por e-mail
(fora do sistema), importar o PTI respondido (parâmetros de programação) e
aprovar ou reprovar.

### 1.4 Etapas do Atacado
Criar o Pré-PTI, salvar rascunhos, finalizar (enviar), criar novas versões e
excluir formulários.

### 1.5 Passagem de responsabilidade
Implícita na troca de `status`. Não registrava quem passou, quando, por quê,
nem o que se esperava da outra equipe. "Reprovar" não pedia motivo.

### 1.6 Regras de acesso
`login_required` e `role_required` por perfil. O Atacado vê e edita só os
próprios formulários; a Engenharia vê todos. O administrador (código de acesso)
só cadastra usuários.

### 1.7 Campos de data
`created_at` e `updated_at` (UTC, em formatos diferentes) e
`operadora_params_em`. As telas mostravam o horário UTC como se fosse o de
Brasília (3 horas adiantado).

### 1.8 Divergências entre as telas
- A Engenharia via e podia **aprovar um rascunho** que o Atacado nunca enviou.
- O Atacado podia **editar um Pré-PTI já enviado ou aprovado** e até voltá-lo
  para rascunho ao salvar, sem que a Engenharia soubesse.
- Aprovar e reprovar funcionavam a partir de qualquer status.
- "Enviado" não dizia com quem estava nem o que faltava.
- O filtro da Engenharia oferecia "Em revisão", que nunca acontecia; o do
  Atacado não.
- Excluir apagava o registro sem deixar rastro.
- Nenhum prazo, SLA, responsável nominal, pendência ou motivo era guardado.

### 1.9 Fluxo atual
```
Atacado: rascunho ──Finalizar──▶ enviado ──(Engenharia: Aprovar)──▶ aprovado
                       ▲              └──(Engenharia: Reprovar)──▶ reprovado
                       └──────── Atacado edita e finaliza de novo ◀────┘
(sem histórico; qualquer status podia ir para aprovado/reprovado; o Atacado
 podia sobrescrever qualquer um)
```

## 2. Fluxo proposto

Máquina de estados única (`fluxo/definicao.py`), aplicada no servidor para as
duas equipes:

```
             enviar (Atacado)                    aprovar (Engenharia)
Elaboração ───────────────────▶ Validação técnica ─────────────────────▶ Concluído
(Atacado)                       (Engenharia)      ◀─── reabrir (Eng./Adm.) ─┘
                                 │   ▲   │   ▲
          devolver (Engenharia)  │   │   │   │ importar PTI respondido (sistema)
          com motivo obrigatório ▼   │   ▼   │ ou retomar sem resposta (Eng.)
                         Ajustes do Atacado   Resposta da operadora
                         (Atacado) ─reenviar─┘ (Integração externa)

Qualquer etapa aberta ──cancelar (Atacado dono ou Adm., com motivo)──▶ Cancelado
Cancelado ──reabrir (Atacado dono ou Adm.)──▶ Elaboração
```

- **Situação dentro da etapa:** ativo, pausado ou bloqueado (com motivo e de
  quem depende). Pausa e bloqueio param o relógio do SLA e são contados à parte.
- **Responsável sempre definido:** a etapa seguinte é aberta na mesma transação
  que encerra a anterior; não existe instante sem área responsável.
- **Usuário responsável:** o dono do formulário nas etapas do Atacado; na
  Engenharia, quem "assumir" a validação (ou salvar a validação primeiro).
- **Permissões:** ver é igual para todos os autorizados; agir depende da área
  responsável, do perfil, da etapa e da regra de transição. O botão
  indisponível diz quem é responsável e o que precisa acontecer.
- **Atacado fora da sua vez:** o formulário abre somente para leitura enquanto
  o processo estiver com a Engenharia, a operadora ou encerrado.
- **Excluir:** só para Pré-PTI ainda não enviado; depois do primeiro envio, a
  saída é "Cancelar" (com motivo). Os eventos de um processo excluído ficam.

## 3. Modelo de dados

| Tabela | Papel |
|---|---|
| `pti_processos` | Estado atual de cada processo (uma linha por formulário): etapa, situação, área e usuário responsáveis, desde quando, prioridade, tipo, primeiro envio, conclusão, contadores de retorno e reabertura, última movimentação e versão do registro (controle de concorrência). **Única fonte de verdade.** |
| `pti_etapas` | Cada passagem por uma etapa: área, usuário, início, fim, ocorrência (1ª, 2ª…), prazo vigente, desfecho e tempos úteis consumidos (ativo, pausado, bloqueado). Base do SLA por etapa e por equipe. |
| `pti_situacoes` | Intervalos de pausa e bloqueio (tipo, motivo, de quem depende, início, fim, quem abriu e quem encerrou). |
| `pti_eventos` | Trilha de auditoria somente inserção (gatilhos impedem alterar ou apagar): tipo, data e hora, origem, autor, etapa, status, área e usuário antes e depois, ação esperada, motivo, comentário, pendências abertas no momento, documentos, dados alterados, tempo consumido na etapa anterior, prazo e situação do SLA. |
| `pti_pendencias` | Pendências abertas e resolvidas, com área responsável e indicação de bloqueio. |
| `pti_alertas` e `pti_alertas_leitura` | Alertas por área ou usuário, com a ação necessária e a leitura de cada usuário. |

A coluna `atacado_forms.status` continua existindo (filtros e telas antigas),
mas só o serviço do fluxo a grava, derivada da etapa, na mesma transação.

## 4. SLA

- Prazos por etapa em dias úteis (segunda a sexta, horário de Brasília), em
  `config.py` (`SLA_ETAPAS_DIAS_UTEIS`, `SLA_TOTAL_DIAS_UTEIS`). **Os valores
  iniciais são uma proposta e devem ser confirmados pelas equipes.** Feriados não
  são considerados.
- SLA da etapa = tempo útil na etapa menos pausas e bloqueios.
- SLA total = do primeiro envio à conclusão, menos pausas e bloqueios.
- Situações: no prazo, próximo do vencimento (75% do prazo), vencido,
  suspenso (pausado/bloqueado), cumprido, descumprido, sem SLA.
- O tempo de cada etapa fica atribuído à área registrada naquele período,
  nunca a quem concluiu o processo.

## 5. Implementação

| Peça | Arquivo |
|---|---|
| Etapas, áreas, ações, regras de transição e permissão, frases de situação | `fluxo/definicao.py` |
| Tempo útil (dias úteis, Brasília), SLA e formatação | `fluxo/tempo.py` |
| Tabelas, gatilhos de auditoria, visão `vw_pti_etapas` e migração | `fluxo/esquema.py` (chamado por `db.init_db`) |
| Serviço transacional: toda mudança de estado | `fluxo/servico.py` |
| Leitura: estado, linha do tempo, histórico, tempos por equipe | `fluxo/consultas.py` |
| Indicadores e filtros | `fluxo/indicadores.py` |
| Alertas de evento e de prazo | `fluxo/alertas.py` |
| Telas e API | `routes/processos.py`: `/processos/<id>`, `/processos/<id>/acao`, `/indicadores`, `/alertas`, `/api/processos/<id>`, `/api/indicadores` |
| Integração com as telas existentes | `routes/atacado.py`, `routes/engenharia.py`, `routes/central.py` |
| Interface | `templates/processo.html`, `indicadores.html`, `alertas.html`, `_macros/fluxo.html`, `static/css/fluxo.css` |
| Testes | `tests/test_fluxo.py` (`python -m unittest discover -s tests`) |

### 5.1 O que mudou nas telas existentes
- **Listas (Atacado e Engenharia) e painel:** a coluna "Status" virou
  "Situação": frase específica, com quem está, há quanto tempo, SLA e
  pendências. Link "Linha do tempo" em cada linha. Os filtros usam os nomes das
  etapas (valores iguais aos de antes, mais "Cancelado").
- **Engenharia:** "Aprovar" e "Reprovar" saíram da lista (marcação comentada no
  template) e passaram para a linha do tempo: aprovar exige não haver
  pendências; devolver exige o motivo e aceita pendências (uma por linha). As
  rotas antigas `/validar` e `/reprovar` continuam e passam pelas mesmas regras.
- **Formulário:** resumo do processo no topo. Fora da etapa de quem está vendo,
  o formulário abre só para consulta (o servidor recusa a gravação com a
  explicação). "Finalizar" virou "Enviar à Engenharia" ("Reenviar…" nos ajustes).
- **Excluir:** aparece só para Pré-PTI ainda não enviado; depois, "Cancelar
  processo" na linha do tempo.
- **Barra superior:** link "Indicadores" e sino de alertas com a contagem de não
  lidos.
- **Datas:** o filtro `date_br` passou a converter de UTC para o horário de
  Brasília (antes mostrava 3 horas adiantado).

### 5.2 Operação
- `flask pti-alertas` gera os alertas de prazo (também rodam sozinhos a cada
  5 minutos durante o uso).
- `VIVOHUB_DB=<arquivo>` aponta a aplicação para outro banco (testes e QA em
  cópia; `tools/qa/regressao.py` já usa uma cópia nos dois lados).
- Para dashboards externos: `vw_pti_etapas` (cada passagem por etapa, com área,
  tempos e SLA) e `/api/indicadores` (mesmos filtros da tela).

## 6. Decisões tomadas

| Decisão | Motivo |
|---|---|
| `atacado_forms.status` mantido como coluna derivada | Filtros, contadores e o builder do Excel continuam funcionando sem mudança; só o serviço grava. |
| Tabelas do fluxo sem chave estrangeira para `atacado_forms` | O histórico de um formulário excluído fica para auditoria. |
| "Resposta da operadora" como etapa opcional da Integração externa, executada pela Engenharia | A operadora não usa o sistema; quem registra o envio e importa a resposta é a Engenharia. Concluído sem passar por ela, a etapa aparece como "não utilizada". |
| Envio pelo formulário, não pela linha do tempo | O formulário confere os campos obrigatórios antes de enviar. |
| Trava otimista (`versao_registro`) nas decisões da linha do tempo | Duas pessoas decidindo ao mesmo tempo: a segunda recebe aviso e vê a situação nova. No formulário vale a regra de etapa (quem não está na sua etapa não grava). |
| Registros antigos migrados com origem "Migração" | Não existe histórico anterior: o estado vem do status e a data da etapa atual é a última atualização do formulário (estimativa). A etapa atual recebe o SLA configurado. |
| Engenheiro que salva a validação vira o responsável, se ninguém assumiu | O responsável nominal passa a existir sem exigir um clique a mais. |
| Alertas do Atacado só para o dono do Pré-PTI; da Engenharia, para a área | Mesma regra de acesso que já existia (o Atacado vê só os próprios). |
| Administração = usuário logado que validou o código de administrador | O código de administrador já existia; não há perfil "administrador" na tabela de usuários. |

## 7. Pendências para confirmar
- **Valores de SLA** (`config.py`): validação técnica 3, ajustes 2, resposta da
  operadora 5 e total 10 dias úteis; "próximo do vencimento" a 75%; "sem
  movimentação" após 3 dias úteis. São propostas.
- **Feriados** não são considerados nos dias úteis.
- **Registros migrados** (#11, #12, #26): as datas de envio e conclusão são
  estimadas pela última atualização do formulário.
