"""Operações do fluxo do PTI: toda mudança de estado passa por aqui.

Cada operação:
  1. confere a regra (definicao.verificar) — transições inválidas são barradas;
  2. grava o evento na trilha de auditoria (somente inserção);
  3. encerra a etapa anterior e abre a seguinte na mesma transação, para o
     processo nunca ficar sem área responsável;
  4. atualiza o estado atual (pti_processos) e o status derivado do formulário;
  5. cria os alertas para quem precisa agir.

As funções não fazem commit: quem chama envolve a operação em `transacao(db)`.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager

from config import SLA_ETAPAS_DIAS_UTEIS
from fluxo import consultas
from fluxo.esquema import migrar_formularios
from fluxo.definicao import (
    ACOES, AREAS, ETAPAS, EVENTOS, PRIORIDADES, ROTULOS_CAMPOS, SISTEMA, TIPOS_BLOQUEIO, Ator,
    com_area, da_area, nome_area, verificar,
)
from fluxo.tempo import agora, formatar_data, gravar


def _frase(texto: str | None) -> str:
    """Texto livre do usuário dentro de uma frase: sem espaços nem ponto final duplicado."""
    return (texto or "").strip().rstrip(".")


class FluxoErro(Exception):
    """Operação recusada; a mensagem é exibida ao usuário."""


class ConflitoVersao(FluxoErro):
    """O processo mudou desde que a página foi aberta."""


@contextmanager
def transacao(db: sqlite3.Connection):
    """BEGIN IMMEDIATE … COMMIT (ou ROLLBACK em caso de erro)."""
    if not db.in_transaction:
        db.execute("BEGIN IMMEDIATE")
    try:
        yield
    except BaseException:
        db.rollback()
        raise
    else:
        db.commit()


# Desfecho gravado na passagem encerrada, por ação
_DESFECHO = {
    "enviar": "concluida", "reenviar": "concluida", "aprovar": "concluida",
    "enviar_operadora": "concluida", "registrar_resposta": "concluida",
    "devolver": "devolvida", "retomar_validacao": "interrompida",
    "cancelar": "cancelada", "reabrir_concluido": "reaberta", "reabrir_cancelado": "reaberta",
}


class Fluxo:
    def __init__(self, db: sqlite3.Connection, ator: Ator = SISTEMA):
        self.db = db
        self.ator = ator

    # ------------------------------------------------------------------ leitura
    def _proc(self, form_id: int) -> dict:
        row = consultas.processo(self.db, form_id)
        if not row and self._form(form_id):
            # Formulário gravado sem processo (ex.: por uma versão antiga do
            # sistema rodando no mesmo banco): migra na hora, como no startup
            if self.db.in_transaction:
                migrar_formularios(self.db)
            else:
                with transacao(self.db):
                    migrar_formularios(self.db)
            row = consultas.processo(self.db, form_id)
        if not row:
            raise FluxoErro(f"O Pré-PTI #{form_id} não tem linha do tempo.")
        return dict(row)

    def processo(self, form_id: int) -> dict:
        """Estado atual do processo (migra na hora o formulário que não tem)."""
        return self._proc(form_id)

    def _form(self, form_id: int):
        return self.db.execute(
            "SELECT id, owner_id, status, nome_operadora, version, updated_at FROM atacado_forms WHERE id = ?",
            (form_id,)).fetchone()

    def _abertas(self, form_id: int) -> list:
        return consultas.pendencias(self.db, form_id, abertas=True)

    def pode(self, acao: str, form_id: int) -> tuple[bool, str]:
        proc = self._proc(form_id)
        form = self._form(form_id)
        return verificar(acao, proc, self.ator, dono_id=form["owner_id"] if form else None,
                         pendencias_abertas=len(self._abertas(form_id)))

    def _exigir(self, acao: str, form_id: int, versao: int | None = None) -> dict:
        proc = self._proc(form_id)
        if versao is not None and int(versao) != proc["versao_registro"]:
            raise ConflitoVersao("O processo foi atualizado por outra pessoa desde que você abriu a página. "
                                 "Confira a situação atual e tente de novo.")
        if self.ator is not SISTEMA:
            ok, msg = self.pode(acao, form_id)
            if not ok:
                raise FluxoErro(msg)
        return proc

    # ------------------------------------------------------------------ escrita
    def _evento(self, form_id: int, tipo: str, *, origem: str | None = None, **campos) -> int:
        """Insere um evento na trilha de auditoria e devolve o id."""
        abertas = [{"id": p["id"], "descricao": p["descricao"], "area": p["area_responsavel"],
                    "bloqueante": bool(p["bloqueante"])} for p in self._abertas(form_id)]
        base = {
            "form_id": form_id, "tipo": tipo, "ocorrido_em": gravar(agora()),
            "origem": origem or self.ator.origem,
            "usuario_id": self.ator.usuario_id, "usuario_email": self.ator.email,
            "pendencias_json": json.dumps(abertas, ensure_ascii=False) if abertas else None,
        }
        base.update({k: v for k, v in campos.items() if v is not None})
        cols = list(base)
        cur = self.db.execute(
            f"INSERT INTO pti_eventos ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})",
            [base[c] for c in cols])
        return cur.lastrowid

    def _abrir_etapa(self, form_id: int, etapa: str, usuario_id: int | None, quando) -> int:
        e = ETAPAS[etapa]
        ocorrencia = self.db.execute(
            "SELECT COUNT(*) FROM pti_etapas WHERE form_id = ? AND etapa = ?", (form_id, etapa)).fetchone()[0] + 1
        cur = self.db.execute(
            "INSERT INTO pti_etapas (form_id, etapa, ocorrencia, area, usuario_id, inicio_em, sla_dias_uteis) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (form_id, etapa, ocorrencia, e.area, usuario_id, gravar(quando),
             None if e.terminal else SLA_ETAPAS_DIAS_UTEIS.get(etapa)))
        return cur.lastrowid

    def _fechar_etapa(self, inst_id: int, desfecho: str, proxima: str | None, quando, evento_id: int) -> dict:
        """Encerra a passagem por etapa (e a pausa/bloqueio em aberto) e grava os tempos úteis."""
        self.db.execute(
            "UPDATE pti_situacoes SET fim_em = ?, usuario_fim_id = ? WHERE etapa_instancia_id = ? AND fim_em IS NULL",
            (gravar(quando), self.ator.usuario_id, inst_id))
        inst = self.db.execute("SELECT * FROM pti_etapas WHERE id = ?", (inst_id,)).fetchone()
        t = consultas.tempos_instancia(self.db, inst, ate=quando)
        self.db.execute(
            "UPDATE pti_etapas SET fim_em = ?, desfecho = ?, proxima_etapa = ?, tempo_util_s = ?, "
            "tempo_pausado_s = ?, tempo_bloqueado_s = ?, evento_fim_id = ? WHERE id = ?",
            (gravar(quando), desfecho, proxima, t["util_s"], t["pausado_s"], t["bloqueado_s"], evento_id, inst_id))
        return t

    def _atualizar(self, form_id: int, **campos) -> None:
        """Atualiza o estado atual e incrementa a versão do registro (trava otimista)."""
        sets = ", ".join(f"{k} = ?" for k in campos)
        self.db.execute(
            f"UPDATE pti_processos SET {sets}, versao_registro = versao_registro + 1 WHERE form_id = ?",
            list(campos.values()) + [form_id])

    def _encerrar_pendencias_bloqueio(self, form_id: int, quando, texto: str) -> None:
        """O bloqueio registrado como pendência se encerra junto com o bloqueio."""
        self.db.execute(
            "UPDATE pti_pendencias SET resolvida_em = ?, resolvida_por = ?, resolucao = ? "
            "WHERE form_id = ? AND bloqueante = 1 AND resolvida_em IS NULL",
            (gravar(quando), self.ator.usuario_id, texto, form_id))

    def _usuario_engenharia_anterior(self, form_id: int) -> int | None:
        row = self.db.execute(
            "SELECT usuario_id FROM pti_etapas WHERE form_id = ? AND etapa = 'validacao_tecnica' "
            "AND usuario_id IS NOT NULL ORDER BY inicio_em DESC LIMIT 1", (form_id,)).fetchone()
        return row["usuario_id"] if row else None

    # ------------------------------------------------------------------ alertas
    def _alertar(self, form_id: int, evento_id: int | None, tipo: str, area: str, mensagem: str,
                 acao: str = "", chave: str | None = None) -> None:
        """Alerta para uma área; no Atacado, só o dono do Pré-PTI recebe."""
        if area not in ("engenharia", "atacado"):
            return
        form = self._form(form_id)
        usuario = form["owner_id"] if area == "atacado" and form else None
        self.db.execute(
            "INSERT OR IGNORE INTO pti_alertas (form_id, evento_id, tipo, area_destino, usuario_destino_id, "
            "mensagem, acao, criado_em, chave) VALUES (?,?,?,?,?,?,?,?,?)",
            (form_id, evento_id, tipo, area, usuario, mensagem, acao, gravar(agora()), chave))

    def _rotulo(self, form_id: int) -> str:
        f = self._form(form_id)
        return f"Pré-PTI #{form_id}" + (f" ({f['nome_operadora']} v{f['version'] or 1})" if f and f["nome_operadora"] else "")

    # ------------------------------------------------------------------ transição
    def _transitar(self, form_id: int, acao: str, *, versao=None, motivo=None, comentario=None,
                   documentos=None, origem=None, para: str | None = None) -> int:
        a = ACOES[acao]
        proc = self._exigir(acao, form_id, versao)
        if a.motivo and not (motivo or "").strip():
            raise FluxoErro("Informe o motivo para esta ação.")
        destino = para or a.para
        quando = agora()
        form = self._form(form_id)
        inst_atual = self.db.execute("SELECT * FROM pti_etapas WHERE id = ?", (proc["etapa_instancia_id"],)).fetchone()
        t_antes = consultas.tempos_instancia(self.db, inst_atual, ate=quando)

        # Usuário responsável na nova etapa: o dono (Atacado); na Engenharia, quem
        # agiu (se for engenheiro) ou o engenheiro que já validou; ninguém na
        # integração e no encerramento
        nova = ETAPAS[destino]
        if nova.area == "atacado":
            usuario_novo = form["owner_id"] if form else None
        elif nova.area == "engenharia":
            usuario_novo = ((self.ator.usuario_id if self.ator.perfil == "engenharia" else None)
                            or self._usuario_engenharia_anterior(form_id))
        else:
            usuario_novo = None
        if proc["situacao"] == "bloqueado":
            self._encerrar_pendencias_bloqueio(form_id, quando, f"Encerrado com a ação \"{a.nome}\".")

        nova_inst = self._abrir_etapa(form_id, destino, usuario_novo, quando)
        evento_id = self._evento(
            form_id, a.evento, origem=origem,
            etapa_anterior=proc["etapa"], etapa_nova=destino,
            status_anterior=ETAPAS[proc["etapa"]].status, status_novo=nova.status,
            area_anterior=proc["area_responsavel"], area_nova=nova.area,
            usuario_resp_anterior=proc["usuario_responsavel_id"], usuario_resp_novo=usuario_novo,
            situacao_anterior=proc["situacao"], situacao_nova="ativo",
            acao_esperada=nova.acao, motivo=(motivo or "").strip() or None,
            comentario=(comentario or "").strip() or None,
            documentos_json=json.dumps(documentos, ensure_ascii=False) if documentos else None,
            tempo_etapa_anterior_s=t_antes["ativo_s"],
            prazo_em=gravar(t_antes["prazo_em"]) if t_antes["prazo_em"] else None,
            situacao_sla=t_antes["sla"], etapa_instancia_id=nova_inst,
        )
        self._fechar_etapa(proc["etapa_instancia_id"], _DESFECHO.get(acao, "concluida"), destino, quando, evento_id)
        self.db.execute("UPDATE pti_etapas SET evento_inicio_id = ? WHERE id = ?", (evento_id, nova_inst))

        campos = dict(
            etapa=destino, situacao="ativo", motivo_situacao=None, area_dependencia=None,
            area_responsavel=nova.area, usuario_responsavel_id=usuario_novo,
            responsavel_desde=gravar(quando), etapa_instancia_id=nova_inst,
            ultimo_evento_id=evento_id, ultima_movimentacao_em=gravar(quando),
        )
        if acao == "enviar" and not proc["primeiro_envio_em"]:
            campos["primeiro_envio_em"] = gravar(quando)
        if acao == "devolver":
            campos["retornos"] = proc["retornos"] + 1
        if acao.startswith("reabrir"):
            campos["reaberturas"] = proc["reaberturas"] + 1
            campos["concluido_em"] = None
            campos["cancelado_em"] = None
        if destino == "concluido":
            campos["concluido_em"] = gravar(quando)
        if destino == "cancelado":
            campos["cancelado_em"] = gravar(quando)
        self._atualizar(form_id, **campos)
        # Status derivado (compatibilidade com filtros e telas antigas)
        self.db.execute("UPDATE atacado_forms SET status = ?, updated_at = ? WHERE id = ?",
                        (nova.status, gravar(quando), form_id))

        # Alertas para quem precisa agir
        rotulo = self._rotulo(form_id)
        if destino == "concluido":
            self._alertar(form_id, evento_id, "concluido", "atacado", f"{rotulo} foi concluído pela Engenharia.",
                          "Consultar a linha do tempo e baixar o PTI, se necessário.")
        elif destino == "cancelado":
            outra = "engenharia" if self.ator.perfil == "atacado" else "atacado"
            self._alertar(form_id, evento_id, "cancelado", outra, f"{rotulo} foi cancelado: {_frase(motivo)}.", "Nenhuma ação.")
        else:
            tipo = {"devolver": "devolvido", "reabrir_concluido": "reaberto",
                    "reabrir_cancelado": "reaberto"}.get(acao, "nova_responsabilidade")
            extra = f" Motivo: {_frase(motivo)}." if motivo else ""
            self._alertar(form_id, evento_id, tipo, nova.executor,
                          f"{rotulo}: {EVENTOS[a.evento]}. Responsável agora: {nome_area(nova.area)}.{extra}",
                          nova.acao)
        return evento_id

    # ------------------------------------------------------------------ criação
    def criar_processo(self, form_id: int, *, versao_de: int | None = None) -> int:
        """Abre a linha do tempo de um formulário recém-criado (etapa Elaboração)."""
        form = self._form(form_id)
        quando = agora()
        inst = self._abrir_etapa(form_id, "elaboracao", form["owner_id"], quando)
        tipo_ev = "versao_criada" if versao_de else "processo_criado"
        evento_id = self._evento(
            form_id, tipo_ev, etapa_nova="elaboracao", status_novo="rascunho",
            area_nova="atacado", usuario_resp_novo=form["owner_id"],
            acao_esperada=ETAPAS["elaboracao"].acao, situacao_nova="ativo",
            comentario=f"Criado a partir do Pré-PTI #{versao_de}." if versao_de else None,
            etapa_instancia_id=inst)
        self.db.execute("UPDATE pti_etapas SET evento_inicio_id = ? WHERE id = ?", (evento_id, inst))
        self.db.execute(
            "INSERT INTO pti_processos (form_id, etapa, area_responsavel, usuario_responsavel_id, responsavel_desde, "
            "etapa_instancia_id, tipo_processo, criado_em, ultimo_evento_id, ultima_movimentacao_em) "
            "VALUES (?, 'elaboracao', 'atacado', ?, ?, ?, ?, ?, ?, ?)",
            (form_id, form["owner_id"], gravar(quando), inst, "nova_versao" if versao_de else "novo",
             gravar(quando), evento_id, gravar(quando)))
        self.db.execute("UPDATE atacado_forms SET status = 'rascunho' WHERE id = ?", (form_id,))
        if versao_de and consultas.processo(self.db, versao_de):
            ev = self._evento(versao_de, "nova_versao_gerada",
                              comentario=f"Nova versão: Pré-PTI #{form_id} (v{form['version']}).")
            self._atualizar(versao_de, ultimo_evento_id=ev, ultima_movimentacao_em=gravar(quando))
        return evento_id

    # ------------------------------------------------------------------ dados
    def registrar_dados(self, form_id: int, antes, depois: dict, campos) -> int | None:
        """Evento 'Dados atualizados' com o que mudou (sem mudança, sem evento)."""
        proc = self._proc(form_id)
        alterados = {}
        for c in campos:
            va = (antes[c] if antes is not None and c in antes.keys() else None)
            vd = depois.get(c)
            if str(va if va is not None else "") == str(vd if vd is not None else ""):
                continue
            if c.endswith("_json") or (isinstance(vd, str) and len(vd) > 120):
                alterados[c] = "alterado"
            else:
                alterados[c] = {"de": va, "para": vd}
        if not alterados:
            return None
        quando = agora()
        evento_id = self._evento(
            form_id, "dados_atualizados", etapa_anterior=proc["etapa"], etapa_nova=proc["etapa"],
            dados_alterados_json=json.dumps(alterados, ensure_ascii=False, default=str),
            etapa_instancia_id=proc["etapa_instancia_id"])
        campos_proc = dict(ultimo_evento_id=evento_id, ultima_movimentacao_em=gravar(quando))
        # Engenheiro que salva a validação passa a ser o responsável, se ninguém assumiu
        if (self.ator.perfil == "engenharia" and proc["area_responsavel"] == "engenharia"
                and not proc["usuario_responsavel_id"]):
            campos_proc["usuario_responsavel_id"] = self.ator.usuario_id
            self.db.execute("UPDATE pti_etapas SET usuario_id = ? WHERE id = ?",
                            (self.ator.usuario_id, proc["etapa_instancia_id"]))
        self._atualizar(form_id, **campos_proc)
        return evento_id

    def pode_editar(self, form_id: int) -> tuple[bool, str]:
        """O ator pode alterar os dados do formulário agora?"""
        proc = self._proc(form_id)
        etapa = ETAPAS[proc["etapa"]]
        form = self._form(form_id)
        if self.ator.perfil == "atacado":
            if form and form["owner_id"] != self.ator.usuario_id:
                return False, "Só o usuário do Atacado dono deste Pré-PTI pode alterá-lo."
            if etapa.chave in ("elaboracao", "ajustes"):
                return True, ""
            if etapa.terminal:
                return False, f"O processo foi encerrado ({etapa.nome.lower()}). Para alterar, crie uma nova versão ou peça a reabertura."
            return False, (f"O Pré-PTI está {com_area(proc['area_responsavel'])} {etapa.local} desde "
                           f"{formatar_data(proc['responsavel_desde'])}. A edição volta a ficar disponível "
                           "se a Engenharia devolvê-lo para ajustes.")
        if self.ator.perfil == "engenharia":
            if etapa.chave in ("validacao_tecnica", "resposta_operadora"):
                return True, ""
            if etapa.terminal:
                return False, f"O processo foi encerrado ({etapa.nome.lower()}). Reabra-o para alterar a validação."
            return False, (f"O Pré-PTI está {com_area(proc['area_responsavel'])} {etapa.local}; "
                           "a validação fica disponível quando o Atacado enviá-lo.")
        return False, "Perfil sem permissão de edição."

    # ------------------------------------------------------------------ ações de etapa
    def enviar(self, form_id: int, versao=None) -> int:
        """'Finalizar' do Atacado: primeiro envio ou reenvio após ajustes."""
        acao = "reenviar" if self._proc(form_id)["etapa"] == "ajustes" else "enviar"
        return self._transitar(form_id, acao, versao=versao)

    def devolver(self, form_id: int, motivo: str, pendencias: list[str] | None = None, versao=None) -> int:
        """Devolve ao Atacado; cada ponto a corrigir vira uma pendência do Atacado
        (registrada antes, para constar no evento da devolução)."""
        self._exigir("devolver", form_id, versao)
        if not (motivo or "").strip():
            raise FluxoErro("Informe o motivo para esta ação.")
        for item in pendencias or []:
            if item.strip():
                self._pendencia(form_id, item.strip(), "atacado", False, registrar_evento=False)
        return self._transitar(form_id, "devolver", versao=versao, motivo=motivo)

    def aprovar(self, form_id: int, comentario: str | None = None, versao=None) -> int:
        return self._transitar(form_id, "aprovar", versao=versao, comentario=comentario)

    def enviar_operadora(self, form_id: int, comentario: str | None = None, versao=None) -> int:
        return self._transitar(form_id, "enviar_operadora", versao=versao, comentario=comentario)

    def registrar_resposta_operadora(self, form_id: int, documento: dict) -> int:
        """Chamado pela importação do PTI respondido. Na etapa de espera, avança;
        nas demais etapas abertas, só registra o evento."""
        proc = self._proc(form_id)
        if proc["etapa"] == "resposta_operadora":
            return self._transitar(form_id, "registrar_resposta", origem="integracao", documentos=[documento])
        if ETAPAS[proc["etapa"]].terminal:
            raise FluxoErro("O processo foi encerrado; reabra-o para importar novas respostas da operadora.")
        evento_id = self._evento(form_id, "resposta_importada", origem="integracao",
                                 etapa_anterior=proc["etapa"], etapa_nova=proc["etapa"],
                                 documentos_json=json.dumps([documento], ensure_ascii=False),
                                 etapa_instancia_id=proc["etapa_instancia_id"])
        self._atualizar(form_id, ultimo_evento_id=evento_id, ultima_movimentacao_em=gravar(agora()))
        return evento_id

    def retomar_validacao(self, form_id: int, motivo: str, versao=None) -> int:
        return self._transitar(form_id, "retomar_validacao", versao=versao, motivo=motivo)

    def cancelar(self, form_id: int, motivo: str, versao=None) -> int:
        return self._transitar(form_id, "cancelar", versao=versao, motivo=motivo)

    def reabrir(self, form_id: int, motivo: str, versao=None) -> int:
        acao = "reabrir_concluido" if self._proc(form_id)["etapa"] == "concluido" else "reabrir_cancelado"
        return self._transitar(form_id, acao, versao=versao, motivo=motivo)

    # ------------------------------------------------------------------ responsabilidade
    def assumir(self, form_id: int, versao=None) -> int:
        proc = self._exigir("assumir", form_id, versao)
        evento_id = self._evento(
            form_id, "assumido", etapa_anterior=proc["etapa"], etapa_nova=proc["etapa"],
            area_anterior=proc["area_responsavel"], area_nova=proc["area_responsavel"],
            usuario_resp_anterior=proc["usuario_responsavel_id"], usuario_resp_novo=self.ator.usuario_id,
            etapa_instancia_id=proc["etapa_instancia_id"])
        self.db.execute("UPDATE pti_etapas SET usuario_id = ? WHERE id = ?", (self.ator.usuario_id, proc["etapa_instancia_id"]))
        self._atualizar(form_id, usuario_responsavel_id=self.ator.usuario_id,
                        ultimo_evento_id=evento_id, ultima_movimentacao_em=gravar(agora()))
        return evento_id

    def reatribuir(self, form_id: int, area: str, usuario_id: int | None, motivo: str, versao=None) -> int:
        proc = self._exigir("reatribuir", form_id, versao)
        if area not in AREAS or area == "nao_atribuida":
            raise FluxoErro("Escolha uma área responsável válida.")
        if not (motivo or "").strip():
            raise FluxoErro("A correção de responsável exige justificativa.")
        quando = agora()
        evento_id = self._evento(
            form_id, "reatribuido", origem="administracao", etapa_anterior=proc["etapa"], etapa_nova=proc["etapa"],
            area_anterior=proc["area_responsavel"], area_nova=area,
            usuario_resp_anterior=proc["usuario_responsavel_id"], usuario_resp_novo=usuario_id,
            motivo=motivo.strip(), etapa_instancia_id=proc["etapa_instancia_id"])
        self.db.execute("UPDATE pti_etapas SET area = ?, usuario_id = ? WHERE id = ?",
                        (area, usuario_id, proc["etapa_instancia_id"]))
        self._atualizar(form_id, area_responsavel=area, usuario_responsavel_id=usuario_id,
                        responsavel_desde=gravar(quando), ultimo_evento_id=evento_id,
                        ultima_movimentacao_em=gravar(quando))
        self._alertar(form_id, evento_id, "nova_responsabilidade", area,
                      f"{self._rotulo(form_id)} foi atribuído {('ao' if area == 'atacado' else 'à')} {nome_area(area)} "
                      f"pela administração: {_frase(motivo)}.", ETAPAS[proc["etapa"]].acao)
        return evento_id

    # ------------------------------------------------------------------ pausa e bloqueio
    def _situacao(self, form_id: int, acao: str, nova: str, *, motivo=None, tipo_bloqueio=None,
                  area_dependencia=None, versao=None) -> int:
        proc = self._exigir(acao, form_id, versao)
        if ACOES[acao].motivo and not (motivo or "").strip():
            raise FluxoErro("Informe o motivo.")
        quando = agora()
        if nova == "ativo":
            self.db.execute(
                "UPDATE pti_situacoes SET fim_em = ?, usuario_fim_id = ? WHERE etapa_instancia_id = ? AND fim_em IS NULL",
                (gravar(quando), self.ator.usuario_id, proc["etapa_instancia_id"]))
            if proc["situacao"] == "bloqueado":
                self._encerrar_pendencias_bloqueio(form_id, quando, (motivo or "").strip() or "Bloqueio encerrado.")
        else:
            self.db.execute(
                "INSERT INTO pti_situacoes (form_id, etapa_instancia_id, tipo, tipo_bloqueio, motivo, area_dependencia, "
                "inicio_em, usuario_inicio_id) VALUES (?,?,?,?,?,?,?,?)",
                (form_id, proc["etapa_instancia_id"], nova, tipo_bloqueio, motivo.strip(), area_dependencia,
                 gravar(quando), self.ator.usuario_id))
        evento_id = self._evento(
            form_id, ACOES[acao].evento, etapa_anterior=proc["etapa"], etapa_nova=proc["etapa"],
            situacao_anterior=proc["situacao"], situacao_nova=nova,
            area_anterior=proc["area_responsavel"], area_nova=proc["area_responsavel"],
            motivo=(motivo or "").strip() or None, area_destino=area_dependencia,
            etapa_instancia_id=proc["etapa_instancia_id"])
        self._atualizar(
            form_id, situacao=nova,
            motivo_situacao=(motivo or "").strip() if nova != "ativo" else None,
            area_dependencia=area_dependencia if nova == "bloqueado" else None,
            ultimo_evento_id=evento_id, ultima_movimentacao_em=gravar(quando))
        rotulo = self._rotulo(form_id)
        if nova == "bloqueado":
            if area_dependencia:
                self._pendencia(form_id, f"{TIPOS_BLOQUEIO.get(tipo_bloqueio, 'Bloqueio')}: {motivo.strip()}",
                                area_dependencia, True, registrar_evento=False)
            acao_alerta = "Resolver o bloqueio" + (f" (depende {da_area(area_dependencia)})" if area_dependencia else "") + "."
            for area in {proc["area_responsavel"], area_dependencia} - {None}:
                self._alertar(form_id, evento_id, "bloqueado", area, f"{rotulo} está bloqueado: {_frase(motivo)}.",
                              acao_alerta)
        return evento_id

    def pausar(self, form_id: int, motivo: str, versao=None) -> int:
        return self._situacao(form_id, "pausar", "pausado", motivo=motivo, versao=versao)

    def retomar(self, form_id: int, versao=None) -> int:
        return self._situacao(form_id, "retomar", "ativo", versao=versao)

    def bloquear(self, form_id: int, motivo: str, tipo_bloqueio: str, area_dependencia: str | None, versao=None) -> int:
        if tipo_bloqueio not in TIPOS_BLOQUEIO:
            raise FluxoErro("Escolha o tipo de bloqueio.")
        if area_dependencia and area_dependencia not in AREAS:
            raise FluxoErro("Área de dependência inválida.")
        return self._situacao(form_id, "bloquear", "bloqueado", motivo=motivo, tipo_bloqueio=tipo_bloqueio,
                              area_dependencia=area_dependencia or None, versao=versao)

    def desbloquear(self, form_id: int, comentario: str | None = None, versao=None) -> int:
        return self._situacao(form_id, "desbloquear", "ativo", motivo=comentario, versao=versao)

    # ------------------------------------------------------------------ comentários e pendências
    def comentar(self, form_id: int, texto: str, area_destino: str | None = None) -> int:
        proc = self._exigir("comentar", form_id)
        if not (texto or "").strip():
            raise FluxoErro("Escreva o comentário.")
        evento_id = self._evento(form_id, "comentario", comentario=texto.strip(),
                                 area_destino=area_destino or None, etapa_anterior=proc["etapa"],
                                 etapa_nova=proc["etapa"], etapa_instancia_id=proc["etapa_instancia_id"])
        self._atualizar(form_id, ultimo_evento_id=evento_id, ultima_movimentacao_em=gravar(agora()))
        if area_destino:
            self._alertar(form_id, evento_id, "comentario", area_destino,
                          f"Comentário para {nome_area(area_destino)} em {self._rotulo(form_id)}: {texto.strip()[:140]}",
                          "Ler o comentário na linha do tempo.")
        return evento_id

    def _pendencia(self, form_id: int, descricao: str, area: str, bloqueante: bool, *, registrar_evento=True) -> int:
        if area not in AREAS:
            raise FluxoErro("Escolha a área responsável pela pendência.")
        quando = agora()
        cur = self.db.execute(
            "INSERT INTO pti_pendencias (form_id, descricao, area_responsavel, bloqueante, aberta_por, aberta_em) "
            "VALUES (?,?,?,?,?,?)", (form_id, descricao, area, int(bloqueante), self.ator.usuario_id, gravar(quando)))
        pend_id = cur.lastrowid
        if registrar_evento:
            proc = self._proc(form_id)
            evento_id = self._evento(form_id, "pendencia_aberta", comentario=descricao, area_destino=area,
                                     etapa_anterior=proc["etapa"], etapa_nova=proc["etapa"],
                                     etapa_instancia_id=proc["etapa_instancia_id"])
            self.db.execute("UPDATE pti_pendencias SET evento_abertura_id = ? WHERE id = ?", (evento_id, pend_id))
            self._atualizar(form_id, ultimo_evento_id=evento_id, ultima_movimentacao_em=gravar(quando))
            self._alertar(form_id, evento_id, "pendencia", area,
                          f"Nova pendência para {nome_area(area)} em {self._rotulo(form_id)}: {descricao[:140]}",
                          "Resolver a pendência.")
        return pend_id

    def abrir_pendencia(self, form_id: int, descricao: str, area: str) -> int:
        self._exigir("pendencia_abrir", form_id)
        if not (descricao or "").strip():
            raise FluxoErro("Descreva a pendência.")
        return self._pendencia(form_id, descricao.strip(), area, False)

    def resolver_pendencia(self, form_id: int, pendencia_id: int, resolucao: str) -> int:
        proc = self._exigir("pendencia_resolver", form_id)
        p = self.db.execute("SELECT * FROM pti_pendencias WHERE id = ? AND form_id = ?", (pendencia_id, form_id)).fetchone()
        if not p:
            raise FluxoErro("Pendência não encontrada.")
        if p["resolvida_em"]:
            raise FluxoErro("Esta pendência já foi resolvida.")
        if p["bloqueante"] and proc["situacao"] == "bloqueado":
            raise FluxoErro("Esta pendência é o bloqueio do processo: use \"Encerrar bloqueio\".")
        # Resolvem: a equipe responsável pela pendência, a equipe de quem a
        # registrou (ex.: a Engenharia confere a correção pedida) e a administração
        perfil_autor = self.db.execute("SELECT role FROM users WHERE id = ?", (p["aberta_por"],)).fetchone()
        areas_podem = {p["area_responsavel"], perfil_autor["role"] if perfil_autor else None}
        if self.ator.perfil not in areas_podem and not self.ator.admin:
            raise FluxoErro(f"Pendência {da_area(p['area_responsavel'])}: só essa equipe, "
                            "quem a registrou ou a administração resolvem.")
        quando = agora()
        evento_id = self._evento(form_id, "pendencia_resolvida", comentario=(resolucao or "").strip() or None,
                                 motivo=p["descricao"], etapa_anterior=proc["etapa"], etapa_nova=proc["etapa"],
                                 etapa_instancia_id=proc["etapa_instancia_id"])
        self.db.execute("UPDATE pti_pendencias SET resolvida_em = ?, resolvida_por = ?, resolucao = ?, "
                        "evento_resolucao_id = ? WHERE id = ?",
                        (gravar(quando), self.ator.usuario_id, (resolucao or "").strip() or None, evento_id, pendencia_id))
        self._atualizar(form_id, ultimo_evento_id=evento_id, ultima_movimentacao_em=gravar(quando))
        return evento_id

    def alterar_prioridade(self, form_id: int, prioridade: str, motivo: str | None = None, versao=None) -> int:
        proc = self._exigir("prioridade", form_id, versao)
        if prioridade not in PRIORIDADES:
            raise FluxoErro("Prioridade inválida.")
        if prioridade == proc["prioridade"]:
            raise FluxoErro("O processo já está com essa prioridade.")
        evento_id = self._evento(
            form_id, "prioridade_alterada", motivo=(motivo or "").strip() or None,
            dados_alterados_json=json.dumps({"prioridade": {"de": PRIORIDADES[proc["prioridade"]],
                                                            "para": PRIORIDADES[prioridade]}}, ensure_ascii=False),
            etapa_anterior=proc["etapa"], etapa_nova=proc["etapa"], etapa_instancia_id=proc["etapa_instancia_id"])
        self._atualizar(form_id, prioridade=prioridade, ultimo_evento_id=evento_id,
                        ultima_movimentacao_em=gravar(agora()))
        return evento_id

    # ------------------------------------------------------------------ documentos e exclusão
    def registrar_pti_gerado(self, form_id: int, arquivo: str, detalhes: dict | None = None) -> int:
        proc = self._proc(form_id)
        documento = {"tipo": "PTI (Excel)", "arquivo": arquivo, **(detalhes or {})}
        evento_id = self._evento(form_id, "pti_gerado", documentos_json=json.dumps([documento], ensure_ascii=False),
                                 etapa_anterior=proc["etapa"], etapa_nova=proc["etapa"],
                                 etapa_instancia_id=proc["etapa_instancia_id"])
        self._atualizar(form_id, ultimo_evento_id=evento_id, ultima_movimentacao_em=gravar(agora()))
        return evento_id

    def pode_excluir(self, form_id: int) -> tuple[bool, str]:
        proc = self._proc(form_id)
        form = self._form(form_id)
        if self.ator.perfil != "atacado" or not form or form["owner_id"] != self.ator.usuario_id:
            return False, "Só o usuário do Atacado dono do Pré-PTI pode excluí-lo."
        if proc["etapa"] != "elaboracao" or proc["primeiro_envio_em"]:
            return False, ("Este Pré-PTI já foi enviado à Engenharia e tem histórico. "
                           "Use \"Cancelar processo\", que preserva a linha do tempo.")
        return True, ""

    def excluir(self, form_id: int) -> int:
        """Antes de apagar o formulário: encerra a linha do tempo, que fica no banco."""
        ok, msg = self.pode_excluir(form_id)
        if not ok:
            raise FluxoErro(msg)
        proc = self._proc(form_id)
        quando = agora()
        evento_id = self._evento(form_id, "excluido", etapa_anterior=proc["etapa"], etapa_nova="excluido",
                                 status_anterior="rascunho", status_novo="excluido",
                                 area_anterior=proc["area_responsavel"], area_nova="sistema")
        self._fechar_etapa(proc["etapa_instancia_id"], "excluida", "excluido", quando, evento_id)
        inst = self._abrir_etapa(form_id, "excluido", None, quando)
        self._atualizar(form_id, etapa="excluido", area_responsavel="sistema", usuario_responsavel_id=None,
                        responsavel_desde=gravar(quando), etapa_instancia_id=inst, cancelado_em=gravar(quando),
                        ultimo_evento_id=evento_id, ultima_movimentacao_em=gravar(quando))
        return evento_id

    # ------------------------------------------------------------------ despacho (tela da linha do tempo)
    def executar(self, acao: str, form_id: int, dados) -> int:
        """Executa uma ação vinda da tela da linha do tempo.

        `dados` é o request.form (ou dict). Enviar/reenviar ficam no formulário,
        onde os campos obrigatórios são conferidos; a importação do PTI
        respondido fica nos Parâmetros de Programação.
        """
        g = (lambda k: (dados.get(k) or "").strip())
        versao = g("versao_registro") or None
        if acao in ("enviar", "reenviar"):
            raise FluxoErro("O envio é feito no formulário, onde os campos obrigatórios são conferidos.")
        if acao == "registrar_resposta":
            raise FluxoErro("Importe o PTI respondido em Parâmetros de Programação, no formulário de validação.")
        if acao == "devolver":
            return self.devolver(form_id, g("motivo"), [x for x in g("pendencias").splitlines() if x.strip()], versao=versao)
        if acao == "aprovar":
            return self.aprovar(form_id, g("comentario"), versao=versao)
        if acao == "enviar_operadora":
            return self.enviar_operadora(form_id, g("comentario"), versao=versao)
        if acao == "retomar_validacao":
            return self.retomar_validacao(form_id, g("motivo"), versao=versao)
        if acao == "cancelar":
            return self.cancelar(form_id, g("motivo"), versao=versao)
        if acao in ("reabrir", "reabrir_concluido", "reabrir_cancelado"):
            return self.reabrir(form_id, g("motivo"), versao=versao)
        if acao == "assumir":
            return self.assumir(form_id, versao=versao)
        if acao == "reatribuir":
            uid = g("usuario_id")
            return self.reatribuir(form_id, g("area"), int(uid) if uid.isdigit() else None, g("motivo"), versao=versao)
        if acao == "pausar":
            return self.pausar(form_id, g("motivo"), versao=versao)
        if acao == "retomar":
            return self.retomar(form_id, versao=versao)
        if acao == "bloquear":
            return self.bloquear(form_id, g("motivo"), g("tipo_bloqueio"), g("area_dependencia") or None, versao=versao)
        if acao == "desbloquear":
            return self.desbloquear(form_id, g("comentario"), versao=versao)
        if acao == "comentar":
            return self.comentar(form_id, g("texto"), g("area_destino") or None)
        if acao == "pendencia_abrir":
            return self.abrir_pendencia(form_id, g("descricao"), g("area"))
        if acao == "pendencia_resolver":
            pid = g("pendencia_id")
            if not pid.isdigit():
                raise FluxoErro("Pendência não encontrada.")
            return self.resolver_pendencia(form_id, int(pid), g("resolucao"))
        if acao == "prioridade":
            return self.alterar_prioridade(form_id, g("prioridade"), g("motivo"), versao=versao)
        raise FluxoErro("Ação desconhecida.")


def rotulo_campo(campo: str) -> str:
    return ROTULOS_CAMPOS.get(campo, campo)
