"""Alertas: quem precisa agir, o que mudou e o que está atrasado.

Os alertas de evento (nova responsabilidade, devolução, bloqueio, comentário,
pendência, conclusão, cancelamento) são criados pelo serviço na mesma
transação do evento. Os alertas de prazo (SLA próximo do vencimento, vencido,
processo parado, bloqueio prolongado) são gerados aqui, por varredura: a cada
poucos minutos durante o uso e pelo comando `flask pti-alertas` (agendável).

A coluna `chave` (única) impede o mesmo alerta de prazo duas vezes.
"""
from __future__ import annotations

import sqlite3
import time

from config import SEM_MOVIMENTACAO_DIAS_UTEIS
from fluxo import consultas
from fluxo.definicao import ETAPAS, nome_area
from fluxo.tempo import DIA_UTIL, agora, formatar_data, gravar, ler, segundos_uteis

TIPOS_ALERTA: dict[str, str] = {
    "nova_responsabilidade": "Nova responsabilidade",
    "devolvido": "Devolvido para ajustes",
    "reaberto": "Processo reaberto",
    "bloqueado": "Bloqueio",
    "comentario": "Comentário",
    "pendencia": "Pendência",
    "concluido": "Concluído",
    "cancelado": "Cancelado",
    "sla_proximo": "SLA próximo do vencimento",
    "sla_vencido": "SLA vencido",
    "sla_total_vencido": "SLA total vencido",
    "parado": "Sem movimentação",
    "bloqueio_longo": "Bloqueio prolongado",
}

_ultima_varredura = 0.0
INTERVALO_VARREDURA_S = 300


def _inserir(db, form_id, tipo, area, mensagem, acao, chave):
    """Alerta de prazo para a área executora (no Atacado, o dono do Pré-PTI)."""
    if area not in ("engenharia", "atacado"):
        return 0
    usuario = None
    if area == "atacado":
        row = db.execute("SELECT owner_id FROM atacado_forms WHERE id = ?", (form_id,)).fetchone()
        usuario = row["owner_id"] if row else None
    cur = db.execute(
        "INSERT OR IGNORE INTO pti_alertas (form_id, tipo, area_destino, usuario_destino_id, mensagem, acao, "
        "criado_em, chave) VALUES (?,?,?,?,?,?,?,?)",
        (form_id, tipo, area, usuario, mensagem, acao, gravar(agora()), chave))
    return cur.rowcount


def gerar_alertas_de_prazo(db: sqlite3.Connection) -> int:
    """Varre os processos abertos e cria os alertas de prazo que faltam.

    Não faz commit; devolve quantos alertas novos foram criados.
    """
    criados = 0
    procs = db.execute(
        "SELECT p.*, f.nome_operadora, f.version FROM pti_processos p "
        "JOIN atacado_forms f ON f.id = p.form_id").fetchall()
    for p in procs:
        etapa = ETAPAS[p["etapa"]]
        if etapa.terminal:
            continue
        rotulo = f"Pré-PTI #{p['form_id']}" + (f" ({p['nome_operadora']} v{p['version'] or 1})" if p["nome_operadora"] else "")
        inst = consultas.instancia_atual(db, p)
        t = consultas.tempos_instancia(db, inst)
        executor = etapa.executor
        if t["sla"] == "proximo":
            criados += _inserir(db, p["form_id"], "sla_proximo", executor,
                                f"{rotulo}: o SLA da etapa {etapa.nome} vence em {formatar_data(t['prazo_em'])}.",
                                etapa.acao, f"sla_proximo:{inst['id']}")
        elif t["sla"] == "vencido":
            criados += _inserir(db, p["form_id"], "sla_vencido", executor,
                                f"{rotulo}: o SLA da etapa {etapa.nome} venceu em {formatar_data(t['prazo_em'])}.",
                                etapa.acao, f"sla_vencido:{inst['id']}")
        total = consultas.sla_total(db, p)
        if total["sla"] == "vencido":
            for area in ("engenharia", "atacado"):
                criados += _inserir(db, p["form_id"], "sla_total_vencido", area,
                                    f"{rotulo}: o SLA total do processo venceu em {formatar_data(total['prazo_em'])}.",
                                    f"Etapa atual: {etapa.nome}, {nome_area(p['area_responsavel'])}.",
                                    f"sla_total:{p['form_id']}:{area}")
        parado = segundos_uteis(ler(p["ultima_movimentacao_em"]), agora())
        if p["situacao"] == "ativo" and parado >= SEM_MOVIMENTACAO_DIAS_UTEIS * DIA_UTIL:
            criados += _inserir(db, p["form_id"], "parado", executor,
                                f"{rotulo} está sem movimentação há {SEM_MOVIMENTACAO_DIAS_UTEIS} dias úteis "
                                f"{etapa.local}.", etapa.acao,
                                f"parado:{p['form_id']}:{p['ultimo_evento_id']}")
        if p["situacao"] == "bloqueado":
            s = db.execute("SELECT * FROM pti_situacoes WHERE etapa_instancia_id = ? AND fim_em IS NULL "
                           "ORDER BY inicio_em DESC LIMIT 1", (inst["id"],)).fetchone()
            if s and segundos_uteis(ler(s["inicio_em"]), agora()) >= SEM_MOVIMENTACAO_DIAS_UTEIS * DIA_UTIL:
                for area in {executor, s["area_dependencia"]} - {None}:
                    criados += _inserir(db, p["form_id"], "bloqueio_longo", area,
                                        f"{rotulo} está bloqueado há mais de {SEM_MOVIMENTACAO_DIAS_UTEIS} dias úteis: "
                                        f"{s['motivo'].strip().rstrip('.')}.", "Resolver o bloqueio.",
                                        f"bloqueio_longo:{s['id']}:{area}")
    return criados


def varrer_se_preciso(db: sqlite3.Connection) -> None:
    """Varredura de prazo no máximo a cada INTERVALO_VARREDURA_S (durante o uso)."""
    global _ultima_varredura
    if time.monotonic() - _ultima_varredura < INTERVALO_VARREDURA_S:
        return
    _ultima_varredura = time.monotonic()
    try:
        if not db.in_transaction:
            db.execute("BEGIN IMMEDIATE")
        gerar_alertas_de_prazo(db)
        db.commit()
    except sqlite3.OperationalError:
        db.rollback()   # banco ocupado: tenta na próxima varredura


def _filtro_destino(usuario_id: int, perfil: str | None, admin: bool) -> tuple[str, list]:
    """Alertas visíveis: os da área do usuário (no Atacado, só os dele)."""
    if perfil == "atacado":
        return "(a.area_destino = 'atacado' AND a.usuario_destino_id = ?)", [usuario_id]
    if perfil == "engenharia":
        return "(a.area_destino = 'engenharia' AND (a.usuario_destino_id IS NULL OR a.usuario_destino_id = ?))", [usuario_id]
    if admin:
        return "1 = 1", []
    return "0 = 1", []


def nao_lidos(db: sqlite3.Connection, usuario_id: int | None, perfil: str | None, admin: bool = False) -> int:
    if not usuario_id and not admin:
        return 0
    cond, params = _filtro_destino(usuario_id or 0, perfil, admin)
    return db.execute(
        f"SELECT COUNT(*) FROM pti_alertas a WHERE {cond} AND NOT EXISTS "
        "(SELECT 1 FROM pti_alertas_leitura l WHERE l.alerta_id = a.id AND l.usuario_id = ?)",
        params + [usuario_id or 0]).fetchone()[0]


def listar(db: sqlite3.Connection, usuario_id: int | None, perfil: str | None, admin: bool = False,
           *, somente_nao_lidos: bool = False, limite: int = 200) -> list[dict]:
    cond, params = _filtro_destino(usuario_id or 0, perfil, admin)
    sql = (f"SELECT a.*, f.id AS form_existe, f.nome_operadora, f.version, l.lido_em FROM pti_alertas a "
           "LEFT JOIN atacado_forms f ON f.id = a.form_id "
           "LEFT JOIN pti_alertas_leitura l ON l.alerta_id = a.id AND l.usuario_id = ? "
           f"WHERE {cond}")
    if somente_nao_lidos:
        sql += " AND l.lido_em IS NULL"
    sql += " ORDER BY a.criado_em DESC, a.id DESC LIMIT ?"
    rows = db.execute(sql, [usuario_id or 0] + params + [limite]).fetchall()
    return [{**dict(r), "tipo_nome": TIPOS_ALERTA.get(r["tipo"], r["tipo"]),
             "quando": formatar_data(r["criado_em"]), "lido": bool(r["lido_em"]),
             "existe": r["form_existe"] is not None} for r in rows]


def marcar_lidos(db: sqlite3.Connection, usuario_id: int, perfil: str | None, admin: bool = False,
                 ids: list[int] | None = None) -> int:
    """Marca como lidos os alertas indicados (ou todos os visíveis). Não faz commit."""
    cond, params = _filtro_destino(usuario_id, perfil, admin)
    sql = f"SELECT a.id FROM pti_alertas a WHERE {cond}"
    if ids:
        sql += f" AND a.id IN ({','.join('?' * len(ids))})"
        params = params + [int(i) for i in ids]
    alvos = [r["id"] for r in db.execute(sql, params)]
    db.executemany("INSERT OR IGNORE INTO pti_alertas_leitura (alerta_id, usuario_id, lido_em) VALUES (?,?,?)",
                   [(a, usuario_id, gravar(agora())) for a in alvos])
    return len(alvos)
