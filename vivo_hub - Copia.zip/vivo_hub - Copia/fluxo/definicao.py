"""Definição do fluxo do PTI: etapas, áreas, ações e regras.

Tudo o que as telas mostram sobre "onde o processo está", "com quem está" e
"o que falta" sai daqui. Nenhuma tela decide status por conta própria.
"""
from __future__ import annotations

from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Áreas de responsabilidade
# ---------------------------------------------------------------------------
AREAS: dict[str, str] = {
    "engenharia": "Engenharia",
    "atacado": "Atacado",
    "administracao": "Administração da plataforma",
    "integracao": "Integração externa",
    "sistema": "Sistema",
    "compartilhada": "Responsabilidade compartilhada",
    "nao_atribuida": "Responsabilidade não atribuída",
}

# Preposição para frases como "com a Engenharia", "pelo Atacado"
_ARTIGO = {"atacado": "o", "sistema": "o"}


def nome_area(area: str | None) -> str:
    return AREAS.get(area or "nao_atribuida", AREAS["nao_atribuida"])


def com_area(area: str | None) -> str:
    """'com a Engenharia', 'com o Atacado'."""
    return f"com {_ARTIGO.get(area or '', 'a')} {nome_area(area)}"


def a_area(area: str | None) -> str:
    """'a Engenharia', 'o Atacado'."""
    return f"{_ARTIGO.get(area or '', 'a')} {nome_area(area)}"


def da_area(area: str | None) -> str:
    """'da Engenharia', 'do Atacado'."""
    return f"{'do' if _ARTIGO.get(area or '') == 'o' else 'da'} {nome_area(area)}"


def pela_area(area: str | None) -> str:
    """'pela Engenharia', 'pelo Atacado'."""
    return f"{'pelo' if _ARTIGO.get(area or '') == 'o' else 'pela'} {nome_area(area)}"


# ---------------------------------------------------------------------------
# Etapas
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Etapa:
    chave: str
    nome: str
    area: str                 # área responsável enquanto o processo está aqui
    executor: str             # área que executa a ação que faz o processo avançar
    acao: str                 # ação esperada para avançar
    situacao: str             # frase específica para a etapa em andamento
    status: str               # valor derivado gravado em atacado_forms.status
    proxima: str | None       # próxima etapa prevista no caminho normal
    terminal: bool = False
    opcional: bool = False    # etapa que pode ser pulada (aparece como "ignorada")
    local: str = ""           # "na validação técnica": para frases (sem baixar nomes próprios)


ETAPAS: dict[str, Etapa] = {e.chave: e for e in (
    Etapa("elaboracao", "Elaboração do Pré-PTI", "atacado", "atacado",
          "Preencher o Pré-PTI e enviá-lo à Engenharia",
          "Em elaboração pelo Atacado", "rascunho", "validacao_tecnica",
          local="na elaboração do Pré-PTI"),
    Etapa("validacao_tecnica", "Validação técnica", "engenharia", "engenharia",
          "Validar os dados técnicos, escolher os SBCs, preencher a Mask e aprovar ou devolver ao Atacado",
          "Em validação técnica pela Engenharia", "enviado", "concluido",
          local="na validação técnica"),
    Etapa("ajustes", "Ajustes do Atacado", "atacado", "atacado",
          "Corrigir os pontos apontados pela Engenharia e reenviar",
          "Aguardando ajustes do Atacado", "reprovado", "validacao_tecnica",
          local="nos ajustes do Atacado"),
    Etapa("resposta_operadora", "Resposta da operadora", "integracao", "engenharia",
          "Receber da operadora o PTI respondido e importá-lo (Engenharia)",
          "Aguardando retorno da operadora (integração externa)", "em revisão",
          "validacao_tecnica", opcional=True, local="aguardando a resposta da operadora"),
    Etapa("concluido", "Concluído", "sistema", "sistema",
          "Nenhuma — processo concluído",
          "Concluído pela Engenharia", "aprovado", None, terminal=True),
    Etapa("cancelado", "Cancelado", "sistema", "sistema",
          "Nenhuma — processo cancelado",
          "Cancelado", "cancelado", None, terminal=True),
    # Registro mantido só para auditoria: o formulário foi excluído
    Etapa("excluido", "Excluído", "sistema", "sistema",
          "Nenhuma — formulário excluído",
          "Excluído (antes do primeiro envio)", "excluido", None, terminal=True),
)}

# Caminho previsto, na ordem em que aparece na linha do tempo
CAMINHO: tuple[str, ...] = ("elaboracao", "validacao_tecnica", "resposta_operadora", "concluido")

# Status antigo (atacado_forms.status) → etapa, usado na migração
STATUS_PARA_ETAPA: dict[str, str] = {
    "rascunho": "elaboracao", "enviado": "validacao_tecnica",
    "em revisão": "resposta_operadora", "aprovado": "concluido",
    "reprovado": "ajustes", "cancelado": "cancelado",
}

SITUACOES = {"ativo": "Ativo", "pausado": "Pausado", "bloqueado": "Bloqueado"}

TIPOS_BLOQUEIO: dict[str, str] = {
    "ausencia_informacao": "Ausência de informação",
    "dependencia_externa": "Dependência externa",
    "outro": "Outro motivo",
}

PRIORIDADES: dict[str, str] = {"normal": "Normal", "alta": "Alta", "urgente": "Urgente"}
TIPOS_PROCESSO: dict[str, str] = {"novo": "Pré-PTI novo", "nova_versao": "Nova versão"}

ORIGENS: dict[str, str] = {
    "atacado": "Atacado", "engenharia": "Engenharia",
    "administracao": "Administração da plataforma", "sistema": "Sistema",
    "integracao": "Integração externa", "migracao": "Migração (registro anterior à linha do tempo)",
}

# ---------------------------------------------------------------------------
# Eventos (tipo → rótulo no histórico)
# ---------------------------------------------------------------------------
EVENTOS: dict[str, str] = {
    "processo_criado": "Pré-PTI criado",
    "versao_criada": "Criado como nova versão",
    "nova_versao_gerada": "Nova versão criada a partir deste Pré-PTI",
    "estado_importado": "Estado importado do status anterior",
    "dados_atualizados": "Dados atualizados",
    "enviado": "Enviado à Engenharia",
    "reenviado": "Reenviado à Engenharia após ajustes",
    "devolvido": "Devolvido ao Atacado para ajustes",
    "aprovado": "Aprovado e concluído pela Engenharia",
    "enviado_operadora": "PTI enviado à operadora",
    "resposta_importada": "PTI respondido pela operadora importado",
    "validacao_retomada": "Validação retomada sem a resposta da operadora",
    "cancelado": "Processo cancelado",
    "reaberto": "Processo reaberto",
    "assumido": "Responsabilidade assumida",
    "reatribuido": "Responsabilidade reatribuída pela administração",
    "pausado": "Processo pausado",
    "retomado": "Processo retomado",
    "bloqueado": "Processo bloqueado",
    "desbloqueado": "Bloqueio encerrado",
    "comentario": "Comentário",
    "pendencia_aberta": "Pendência registrada",
    "pendencia_resolvida": "Pendência resolvida",
    "prioridade_alterada": "Prioridade alterada",
    "pti_gerado": "PTI gerado (Excel)",
    "excluido": "Formulário excluído",
}

# Eventos que movem o processo de etapa (passagem de responsabilidade)
EVENTOS_DE_TRANSICAO = {
    "enviado", "reenviado", "devolvido", "aprovado", "enviado_operadora",
    "resposta_importada", "validacao_retomada", "cancelado", "reaberto", "estado_importado",
}

# ---------------------------------------------------------------------------
# Ações e regras de transição
# ---------------------------------------------------------------------------
NAO_TERMINAIS = frozenset(k for k, e in ETAPAS.items() if not e.terminal)


@dataclass(frozen=True)
class Acao:
    chave: str
    nome: str
    de: frozenset            # etapas em que a ação é permitida
    executores: frozenset    # 'atacado', 'engenharia', 'administracao', 'executor' (área executora da etapa), 'todos'
    evento: str
    para: str | None = None  # etapa de destino (None = não muda de etapa)
    situacoes: frozenset = field(default_factory=lambda: frozenset({"ativo", "pausado", "bloqueado"}))
    motivo: bool = False     # motivo obrigatório
    dono: bool = True        # Atacado só age nos próprios formulários
    descricao: str = ""      # o que a ação faz (texto do botão/ajuda)


ACOES: dict[str, Acao] = {a.chave: a for a in (
    Acao("enviar", "Enviar à Engenharia", frozenset({"elaboracao"}), frozenset({"atacado"}),
         "enviado", "validacao_tecnica", frozenset({"ativo"}),
         descricao="Encerra a elaboração e passa a responsabilidade para a Engenharia."),
    Acao("reenviar", "Reenviar à Engenharia", frozenset({"ajustes"}), frozenset({"atacado"}),
         "reenviado", "validacao_tecnica", frozenset({"ativo", "bloqueado"}),
         descricao="Entrega os ajustes e devolve a responsabilidade para a Engenharia."),
    Acao("devolver", "Devolver ao Atacado", frozenset({"validacao_tecnica"}), frozenset({"engenharia"}),
         "devolvido", "ajustes", frozenset({"ativo", "bloqueado"}), motivo=True,
         descricao="Devolve o Pré-PTI para ajustes do Atacado. Explique o que precisa ser corrigido."),
    Acao("aprovar", "Aprovar e concluir", frozenset({"validacao_tecnica"}), frozenset({"engenharia"}),
         "aprovado", "concluido", frozenset({"ativo"}),
         descricao="Conclui o processo. Exige não haver pendências abertas."),
    Acao("enviar_operadora", "Registrar envio à operadora", frozenset({"validacao_tecnica"}), frozenset({"engenharia"}),
         "enviado_operadora", "resposta_operadora", frozenset({"ativo"}),
         descricao="Informa que o PTI foi enviado à operadora; o processo passa a aguardar a resposta dela."),
    Acao("registrar_resposta", "Importar o PTI respondido", frozenset({"resposta_operadora"}), frozenset({"engenharia"}),
         "resposta_importada", "validacao_tecnica",
         descricao="Feita pela importação do PTI respondido, nos Parâmetros de Programação."),
    Acao("retomar_validacao", "Retomar sem a resposta", frozenset({"resposta_operadora"}), frozenset({"engenharia"}),
         "validacao_retomada", "validacao_tecnica", motivo=True,
         descricao="Volta à validação técnica sem esperar a operadora. Informe o motivo."),
    Acao("cancelar", "Cancelar processo", NAO_TERMINAIS, frozenset({"atacado", "administracao"}),
         "cancelado", "cancelado", motivo=True,
         descricao="Encerra o processo sem conclusão. O histórico é preservado."),
    Acao("reabrir_concluido", "Reabrir", frozenset({"concluido"}), frozenset({"engenharia", "administracao"}),
         "reaberto", "validacao_tecnica", motivo=True,
         descricao="Reabre o processo concluído na validação técnica. O histórico é preservado."),
    Acao("reabrir_cancelado", "Reabrir", frozenset({"cancelado"}), frozenset({"atacado", "administracao"}),
         "reaberto", "elaboracao", motivo=True,
         descricao="Reabre o processo cancelado na elaboração. O histórico é preservado."),
    Acao("assumir", "Assumir a validação", frozenset({"validacao_tecnica", "resposta_operadora"}),
         frozenset({"engenharia"}), "assumido",
         descricao="Define você como usuário responsável pela etapa atual."),
    Acao("pausar", "Pausar", NAO_TERMINAIS, frozenset({"executor", "administracao"}), "pausado",
         situacoes=frozenset({"ativo"}), motivo=True,
         descricao="Suspende o processo e o relógio do SLA. Informe o motivo."),
    Acao("retomar", "Retomar", NAO_TERMINAIS, frozenset({"executor", "administracao"}), "retomado",
         situacoes=frozenset({"pausado"}),
         descricao="Encerra a pausa e volta a contar o SLA."),
    Acao("bloquear", "Registrar bloqueio", NAO_TERMINAIS, frozenset({"executor", "administracao"}), "bloqueado",
         situacoes=frozenset({"ativo"}), motivo=True,
         descricao="Marca o processo como bloqueado e indica de quem depende o desbloqueio."),
    Acao("desbloquear", "Encerrar bloqueio", NAO_TERMINAIS, frozenset({"executor", "dependencia", "administracao"}),
         "desbloqueado", situacoes=frozenset({"bloqueado"}),
         descricao="Encerra o bloqueio e volta a contar o SLA."),
    Acao("reatribuir", "Corrigir responsável", NAO_TERMINAIS, frozenset({"administracao"}), "reatribuido",
         motivo=True, descricao="Correção da administração; exige justificativa."),
    Acao("comentar", "Comentar", frozenset(ETAPAS), frozenset({"todos"}), "comentario",
         descricao="Registra um comentário no histórico, opcionalmente direcionado a uma equipe."),
    Acao("pendencia_abrir", "Registrar pendência", NAO_TERMINAIS, frozenset({"todos"}), "pendencia_aberta",
         descricao="Registra o que falta para o processo avançar e quem deve resolver."),
    Acao("pendencia_resolver", "Resolver pendência", NAO_TERMINAIS, frozenset({"todos"}), "pendencia_resolvida",
         descricao="Marca a pendência como resolvida."),
    Acao("prioridade", "Alterar prioridade", NAO_TERMINAIS, frozenset({"atacado", "engenharia", "administracao"}),
         "prioridade_alterada", descricao="Muda a prioridade do processo."),
)}

# Campos do formulário com nome legível (dados alterados no histórico)
ROTULOS_CAMPOS: dict[str, str] = {
    "nome_operadora": "Nome da operadora", "rn1": "RN1", "redes": "Redes", "asn": "ASN",
    "responsavel_operadora": "Responsável da operadora", "responsavel_infra": "Responsável pela infraestrutura",
    "escopo_text": "Descrição do tráfego", "escopo_flags_json": "Tipos de tráfego",
    "dados_vivo_json": "Dados VIVO", "dados_operadora_json": "Dados da operadora",
    "engenharia_params_json": "Observações da Engenharia", "trafego_metricas_json": "Dimensionamento por tráfego",
    "csp": "CSP", "servicos_especiais": "Serviços especiais", "cng": "CNG", "scm": "SCM", "av": "AV",
    "projeto_padrao": "Projeto padrão", "sbc_ativo": "SBC ativo", "ip_reservado": "IP reservado",
    "vivo_reserva": "Vivo reserva IP", "operadora_ciente": "Operadora ciente da responsabilidade",
    "lcr_nacional": "LCR Nacional", "white_list": "White List",
    "prefixos_liberados_abr": "Prefixos liberados na ABR", "premissas_ok": "Aprovação das premissas",
    "atendimento": "Atendimento", "qual": "Qual", "tmr": "TMR",
    "operadora_params_json": "Respostas da operadora",
}


# ---------------------------------------------------------------------------
# Quem está agindo
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Ator:
    usuario_id: int | None
    email: str
    perfil: str | None        # 'atacado' | 'engenharia' | None
    admin: bool = False

    @property
    def origem(self) -> str:
        return self.perfil or ("administracao" if self.admin else "sistema")


SISTEMA = Ator(None, "sistema", None)


def verificar(acao: str, proc: dict, ator: Ator, *, dono_id: int | None = None,
              pendencias_abertas: int = 0) -> tuple[bool, str]:
    """A ação pode ser executada agora por este ator? Retorna (pode, explicação).

    A explicação diz, quando a ação não está disponível, qual equipe é
    responsável, o que está pendente e o que precisa acontecer.
    """
    a = ACOES[acao]
    etapa = ETAPAS[proc["etapa"]]
    situacao = proc.get("situacao") or "ativo"

    if etapa.chave not in a.de:
        if etapa.terminal:
            return False, f"O processo foi encerrado ({etapa.nome.lower()}); não há ação de etapa disponível."
        permitidas = ", ".join(ETAPAS[e].nome for e in CAMINHO + ("ajustes",) if e in a.de)
        return False, (f"Disponível somente em: {permitidas}. "
                       f"Etapa atual: {etapa.nome}, {com_area(etapa.area)}.")

    areas = set(a.executores)
    if "executor" in areas:
        areas.discard("executor")
        areas.add(etapa.executor)
    if "dependencia" in areas:
        areas.discard("dependencia")
        if proc.get("area_dependencia"):
            areas.add(proc["area_dependencia"])

    pode_por_area = (
        "todos" in areas
        or (ator.perfil and ator.perfil in areas)
        or (ator.admin and "administracao" in areas)
    )
    if not pode_por_area:
        quem = " ou ".join(da_area(x) for x in sorted(areas) if x in AREAS) or "de outra equipe"
        return False, (f"Ação {quem}. O processo está {com_area(proc['area_responsavel'])} "
                       f"na etapa {etapa.nome}; próxima ação: {etapa.acao[0].lower() + etapa.acao[1:]}.")

    # Atacado só age nos próprios formulários (regra de acesso já existente)
    if a.dono and ator.perfil == "atacado" and not ator.admin and dono_id is not None and ator.usuario_id != dono_id:
        return False, "Só o usuário do Atacado dono deste Pré-PTI pode executar esta ação."

    if situacao not in a.situacoes:
        if situacao == "pausado":
            return False, f"O processo está pausado ({proc.get('motivo_situacao') or 'sem motivo'}). Retome-o antes."
        if situacao == "bloqueado":
            return False, (f"O processo está bloqueado ({proc.get('motivo_situacao') or 'sem motivo'}). "
                           "Encerre o bloqueio antes.")
        return False, "Disponível somente com o processo pausado ou bloqueado."

    if acao == "aprovar" and pendencias_abertas:
        return False, (f"Há {pendencias_abertas} pendência(s) aberta(s). "
                       "Resolva todas antes de aprovar.")
    if acao == "assumir" and proc.get("usuario_responsavel_id") == ator.usuario_id:
        return False, "Você já é o usuário responsável por esta etapa."
    return True, a.descricao


def frase_situacao(proc: dict, *, usuario_nome: str = "") -> str:
    """Situação específica do processo, sem termos genéricos ("Em andamento")."""
    etapa = ETAPAS[proc["etapa"]]
    situacao = proc.get("situacao") or "ativo"
    motivo = (proc.get("motivo_situacao") or "").strip()
    if situacao == "bloqueado" and not etapa.terminal:
        dep = proc.get("area_dependencia")
        base = f"Bloqueado {etapa.local}"
        if dep:
            base += f", aguardando {a_area(dep)}"
        return f"{base}: {motivo}" if motivo else base
    if situacao == "pausado" and not etapa.terminal:
        return f"Pausado {pela_area(proc.get('area_responsavel'))} {etapa.local}" + (f": {motivo}" if motivo else "")
    frase = etapa.situacao
    if usuario_nome and etapa.chave == "validacao_tecnica":
        frase += f" ({usuario_nome})"
    return frase


def nome_usuario(email: str | None) -> str:
    """'joao.silva@vivo.com' → 'Joao Silva' (mesma regra do restante do sistema)."""
    if not email:
        return ""
    local = email.split("@")[0]
    return local.replace(".", " ").replace("_", " ").title()
