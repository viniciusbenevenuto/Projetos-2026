"""Indicadores do fluxo: consolidados, por etapa, por equipe e por responsável.

Tudo é calculado a partir das tabelas da linha do tempo (pti_processos,
pti_etapas, pti_situacoes, pti_eventos, pti_pendencias). O resultado é um
dicionário serializável em JSON: a tela /indicadores e a API usam o mesmo.

Filtros (todos opcionais):
  inicio, fim    período (dd/mm/aaaa ou aaaa-mm-dd, horário de Brasília): processos
                 ativos em algum momento do período; passagens por etapa que se
                 sobrepõem a ele
  equipe         área (engenharia, atacado, integracao): passagens dessa área e
                 processos abertos que estão com ela
  responsavel    id do usuário: passagens e processos abertos sob ele
  etapa          etapa atual do processo
  tipo           novo | nova_versao
  prioridade     normal | alta | urgente
  sla            situação do SLA da etapa atual (no_prazo, proximo, vencido, suspenso)
  situacao       aberto | concluido | cancelado | bloqueado | pausado
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta

from config import SEM_MOVIMENTACAO_DIAS_UTEIS, SLA_ETAPAS_DIAS_UTEIS
from fluxo import consultas
from fluxo.definicao import (
    AREAS, ETAPAS, PRIORIDADES, SITUACOES, TIPOS_PROCESSO, frase_situacao, nome_area, nome_usuario,
)
from fluxo.tempo import (
    DIA_UTIL, FUSO_BRASILIA, SITUACOES_SLA, agora, formatar_data, formatar_dias_uteis, ler, segundos_uteis,
)

EQUIPES = ("engenharia", "atacado", "integracao")
ETAPAS_DE_TRABALHO = ("elaboracao", "validacao_tecnica", "ajustes", "resposta_operadora")
SITUACOES_FILTRO = {"aberto": "Abertos", "concluido": "Concluídos", "cancelado": "Cancelados",
                    "bloqueado": "Bloqueados", "pausado": "Pausados"}


def _data_local(texto: str | None, fim_do_dia: bool = False) -> datetime | None:
    """'dd/mm/aaaa' ou 'aaaa-mm-dd' (Brasília) → datetime UTC."""
    texto = (texto or "").strip()
    if not texto:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            d = datetime.strptime(texto, fmt)
            break
        except ValueError:
            continue
    else:
        return None
    if fim_do_dia:
        d += timedelta(days=1)
    return d - FUSO_BRASILIA


def _pct(parte: int, todo: int) -> int | None:
    return round(100 * parte / todo) if todo else None


def _media(valores: list[int]) -> int | None:
    return int(sum(valores) / len(valores)) if valores else None


def _dias(segundos: int | None) -> str:
    return formatar_dias_uteis(segundos) if segundos is not None else "—"


def normalizar_filtros(args) -> dict:
    """Lê os filtros de request.args (ou dict) e descarta valores inválidos."""
    g = (lambda k: (args.get(k) or "").strip())
    f = {
        "inicio": g("inicio"), "fim": g("fim"),
        "equipe": g("equipe") if g("equipe") in EQUIPES else "",
        "responsavel": g("responsavel") if g("responsavel").isdigit() else "",
        "etapa": g("etapa") if g("etapa") in ETAPAS else "",
        "tipo": g("tipo") if g("tipo") in TIPOS_PROCESSO else "",
        "prioridade": g("prioridade") if g("prioridade") in PRIORIDADES else "",
        "sla": g("sla") if g("sla") in ("no_prazo", "proximo", "vencido", "suspenso") else "",
        "situacao": g("situacao") if g("situacao") in SITUACOES_FILTRO else "",
    }
    if f["inicio"] and not _data_local(f["inicio"]):
        f["inicio"] = ""
    if f["fim"] and not _data_local(f["fim"]):
        f["fim"] = ""
    return f


def opcoes(db: sqlite3.Connection) -> dict:
    """Valores dos seletores de filtro."""
    usuarios = db.execute(
        "SELECT DISTINCT u.id, u.email, u.role FROM users u WHERE u.id IN "
        "(SELECT usuario_id FROM pti_etapas WHERE usuario_id IS NOT NULL) ORDER BY u.email").fetchall()
    return {
        "equipes": [(k, nome_area(k)) for k in EQUIPES],
        "responsaveis": [(str(u["id"]), f"{nome_usuario(u['email'])} ({nome_area(u['role'])})") for u in usuarios],
        "etapas": [(k, e.nome) for k, e in ETAPAS.items() if k != "excluido"],
        "tipos": list(TIPOS_PROCESSO.items()),
        "prioridades": list(PRIORIDADES.items()),
        "slas": [(k, SITUACOES_SLA[k]) for k in ("no_prazo", "proximo", "vencido", "suspenso")],
        "situacoes": list(SITUACOES_FILTRO.items()),
    }


def calcular(db: sqlite3.Connection, filtros: dict, *, form_ids: set[int] | None = None) -> dict:
    """Indicadores para os filtros informados. form_ids restringe o universo
    (ex.: só os Pré-PTIs do usuário do Atacado)."""
    inicio = _data_local(filtros.get("inicio"))
    fim = _data_local(filtros.get("fim"), fim_do_dia=True)
    agora_ = agora()
    limite = min(fim, agora_) if fim else agora_
    usuarios = {r["id"]: r["email"] for r in db.execute("SELECT id, email FROM users")}

    # ---------------------------------------------------------------- processos
    procs = db.execute(
        "SELECT p.*, f.nome_operadora, f.version, f.owner_id FROM pti_processos p "
        "JOIN atacado_forms f ON f.id = p.form_id ORDER BY p.form_id").fetchall()
    selecionados = []
    for p in procs:
        if form_ids is not None and p["form_id"] not in form_ids:
            continue
        etapa = ETAPAS[p["etapa"]]
        encerrado_em = ler(p["concluido_em"]) or ler(p["cancelado_em"])
        criado = ler(p["criado_em"])
        if fim and criado and criado >= fim:
            continue
        if inicio and encerrado_em and encerrado_em < inicio:
            continue
        if filtros.get("etapa") and p["etapa"] != filtros["etapa"]:
            continue
        if filtros.get("tipo") and p["tipo_processo"] != filtros["tipo"]:
            continue
        if filtros.get("prioridade") and p["prioridade"] != filtros["prioridade"]:
            continue
        sit = filtros.get("situacao")
        if sit == "aberto" and etapa.terminal:
            continue
        if sit == "concluido" and p["etapa"] != "concluido":
            continue
        if sit == "cancelado" and p["etapa"] != "cancelado":
            continue
        if sit in ("bloqueado", "pausado") and (etapa.terminal or p["situacao"] != sit):
            continue
        inst = consultas.instancia_atual(db, p)
        t = consultas.tempos_instancia(db, inst) if not etapa.terminal else None
        sla_atual = t["sla"] if t else "sem_sla"
        if filtros.get("sla") and sla_atual != filtros["sla"]:
            continue
        if filtros.get("equipe") and (etapa.terminal or p["area_responsavel"] != filtros["equipe"]) \
                and not db.execute("SELECT 1 FROM pti_etapas WHERE form_id = ? AND area = ? LIMIT 1",
                                   (p["form_id"], filtros["equipe"])).fetchone():
            continue
        if filtros.get("responsavel") and not db.execute(
                "SELECT 1 FROM pti_etapas WHERE form_id = ? AND usuario_id = ? LIMIT 1",
                (p["form_id"], int(filtros["responsavel"]))).fetchone():
            continue
        selecionados.append((p, etapa, t, sla_atual))

    ids = [p["form_id"] for p, *_ in selecionados]
    abertos = [(p, e, t, s) for p, e, t, s in selecionados if not e.terminal]
    concluidos = [p for p, e, *_ in selecionados if p["etapa"] == "concluido"]
    cancelados = [p for p, e, *_ in selecionados if p["etapa"] == "cancelado"]
    enviados = [p for p, *_ in selecionados if p["primeiro_envio_em"]]

    # SLA total dos concluídos (do primeiro envio à conclusão, sem pausas/bloqueios)
    totais = [consultas.sla_total(db, p) for p in concluidos if p["primeiro_envio_em"]]
    ciclo = [x["consumido_s"] for x in totais]
    pend_abertas = db.execute(
        f"SELECT COUNT(*) FROM pti_pendencias WHERE resolvida_em IS NULL AND form_id IN ({','.join('?' * len(ids)) or 'NULL'})",
        ids).fetchone()[0] if ids else 0

    resumo = {
        "total": len(selecionados),
        "abertos": len(abertos),
        "concluidos": len(concluidos),
        "cancelados": len(cancelados),
        "bloqueados": sum(1 for p, *_ in abertos if p["situacao"] == "bloqueado"),
        "pausados": sum(1 for p, *_ in abertos if p["situacao"] == "pausado"),
        "vencidos": sum(1 for *_, s in abertos if s == "vencido"),
        "proximos": sum(1 for *_, s in abertos if s == "proximo"),
        "sem_movimentacao": sum(
            1 for p, *_ in abertos
            if segundos_uteis(ler(p["ultima_movimentacao_em"]), agora_) >= SEM_MOVIMENTACAO_DIAS_UTEIS * DIA_UTIL),
        "pendencias_abertas": pend_abertas,
        "devolucoes": sum(p["retornos"] for p, *_ in selecionados),
        "taxa_devolucao": _pct(sum(1 for p in enviados if p["retornos"]), len(enviados)),
        "reaberturas": sum(p["reaberturas"] for p, *_ in selecionados),
        "ciclo_medio": _dias(_media(ciclo)),
        "ciclo_medio_s": _media(ciclo),
        "sla_total_cumprido": _pct(sum(1 for x in totais if x["sla"] == "cumprido"), len(totais)),
        "sla_total_avaliados": len(totais),
    }

    # ---------------------------------------------------------------- passagens por etapa
    insts = []
    if ids:
        sql = (f"SELECT * FROM pti_etapas WHERE form_id IN ({','.join('?' * len(ids))}) "
               f"AND etapa IN ({','.join('?' * len(ETAPAS_DE_TRABALHO))})")
        params: list = ids + list(ETAPAS_DE_TRABALHO)
        if filtros.get("equipe"):
            sql += " AND area = ?"
            params.append(filtros["equipe"])
        if filtros.get("responsavel"):
            sql += " AND usuario_id = ?"
            params.append(int(filtros["responsavel"]))
        for inst in db.execute(sql, params):
            ini, fi = ler(inst["inicio_em"]), ler(inst["fim_em"])
            if fim and ini >= fim:
                continue
            if inicio and fi and fi < inicio:
                continue
            insts.append((inst, consultas.tempos_instancia(db, inst, ate=limite)))

    por_etapa = []
    for chave in ETAPAS_DE_TRABALHO:
        grupo = [(i, t) for i, t in insts if i["etapa"] == chave]
        fechadas = [(i, t) for i, t in grupo if i["fim_em"]]
        com_sla = [(i, t) for i, t in fechadas if t["prazo_s"]]
        por_etapa.append({
            "etapa": chave, "nome": ETAPAS[chave].nome, "area_nome": nome_area(ETAPAS[chave].area),
            "passagens": len(grupo), "em_aberto": len(grupo) - len(fechadas),
            "tempo_medio": _dias(_media([t["ativo_s"] for _, t in fechadas])),
            "tempo_maximo": _dias(max([t["ativo_s"] for _, t in grupo], default=None)),
            "sla_previsto": (f"{SLA_ETAPAS_DIAS_UTEIS[chave]} dias úteis"
                             if SLA_ETAPAS_DIAS_UTEIS.get(chave) else "Sem SLA"),
            "sla_cumprido": _pct(sum(1 for _, t in com_sla if t["sla"] == "cumprido"), len(com_sla)),
            "vencidas_abertas": sum(1 for i, t in grupo if not i["fim_em"] and t["sla"] == "vencido"),
            "devolvidas": sum(1 for i, _ in fechadas if i["desfecho"] == "devolvida"),
        })

    # ---------------------------------------------------------------- por equipe
    por_equipe = []
    for area in EQUIPES:
        grupo = [(i, t) for i, t in insts if i["area"] == area]
        fechadas_sla = [(i, t) for i, t in grupo if i["fim_em"] and t["prazo_s"]]
        processos_area = {i["form_id"] for i, _ in grupo}
        ativo = sum(t["ativo_s"] for _, t in grupo)
        por_equipe.append({
            "area": area, "nome": nome_area(area),
            "com_a_equipe": sum(1 for p, *_ in abertos if p["area_responsavel"] == area),
            "processos": len(processos_area),
            "tempo_ativo": _dias(ativo), "tempo_ativo_s": ativo,
            "tempo_medio_processo": _dias(int(ativo / len(processos_area)) if processos_area else None),
            "pausado": _dias(sum(t["pausado_s"] for _, t in grupo)),
            "bloqueado": _dias(sum(t["bloqueado_s"] for _, t in grupo)),
            "aguardando_info": _dias(sum(t["aguardando_info_s"] for _, t in grupo)),
            "retrabalho": _dias(sum(t["ativo_s"] for i, t in grupo
                                    if i["etapa"] == "ajustes" or (i["etapa"] == "validacao_tecnica" and i["ocorrencia"] > 1))),
            "sla_cumprido": _pct(sum(1 for _, t in fechadas_sla if t["sla"] == "cumprido"), len(fechadas_sla)),
            "vencidos_agora": sum(1 for p, e, t, s in abertos if p["area_responsavel"] == area and s == "vencido"),
        })

    # Tempo total por natureza (soma dos processos selecionados)
    naturezas = {k: 0 for k in ("engenharia", "atacado", "integracao", "aguardando_info", "bloqueado",
                                "pausado", "retrabalho", "total")}
    for i, t in insts:
        if i["area"] in naturezas:
            naturezas[i["area"]] += t["ativo_s"]
        naturezas["aguardando_info"] += t["aguardando_info_s"]
        naturezas["bloqueado"] += t["bloqueado_s"]
        naturezas["pausado"] += t["pausado_s"]
        if i["etapa"] == "ajustes" or (i["etapa"] == "validacao_tecnica" and i["ocorrencia"] > 1):
            naturezas["retrabalho"] += t["ativo_s"]
        naturezas["total"] += t["util_s"]
    tempos = [
        ("Engenharia (validação técnica)", naturezas["engenharia"]),
        ("Atacado (elaboração e ajustes)", naturezas["atacado"]),
        ("Integração externa (operadora)", naturezas["integracao"]),
        ("Aguardando informação", naturezas["aguardando_info"]),
        ("Bloqueado", naturezas["bloqueado"]),
        ("Pausado", naturezas["pausado"]),
        ("Retrabalho", naturezas["retrabalho"]),
        ("Total", naturezas["total"]),
    ]

    # ---------------------------------------------------------------- por responsável
    por_usuario: dict[int, dict] = {}
    for i, t in insts:
        if not i["usuario_id"]:
            continue
        u = por_usuario.setdefault(i["usuario_id"], {"passagens": 0, "fechadas": [], "abertas": 0, "areas": set()})
        u["passagens"] += 1
        u["areas"].add(i["area"])
        if i["fim_em"]:
            u["fechadas"].append(t["ativo_s"])
        else:
            u["abertas"] += 1
    por_responsavel = sorted(({
        "usuario_id": uid, "nome": nome_usuario(usuarios.get(uid)) or f"Usuário {uid}",
        "areas": ", ".join(nome_area(a) for a in sorted(u["areas"])),
        "passagens": u["passagens"], "abertas": u["abertas"],
        "tempo_medio": _dias(_media(u["fechadas"])),
    } for uid, u in por_usuario.items()), key=lambda x: x["nome"])

    # ---------------------------------------------------------------- distribuição atual
    distribuicao = []
    for chave in ETAPAS_DE_TRABALHO:
        n = sum(1 for p, *_ in abertos if p["etapa"] == chave)
        distribuicao.append({"etapa": chave, "nome": ETAPAS[chave].nome,
                             "area_nome": nome_area(ETAPAS[chave].area), "n": n})

    # ---------------------------------------------------------------- vazão semanal (8 semanas)
    semanas = []
    hoje_local = (agora_ + FUSO_BRASILIA).date()
    segunda = hoje_local - timedelta(days=hoje_local.weekday())
    if ids:
        eventos = db.execute(
            f"SELECT tipo, ocorrido_em FROM pti_eventos WHERE form_id IN ({','.join('?' * len(ids))}) "
            "AND tipo IN ('enviado', 'aprovado', 'devolvido', 'cancelado') AND origem != 'migracao'", ids).fetchall()
    else:
        eventos = []
    for k in range(7, -1, -1):
        ini = segunda - timedelta(weeks=k)
        fim_sem = ini + timedelta(days=7)
        conta = {"enviado": 0, "aprovado": 0, "devolvido": 0, "cancelado": 0}
        for ev in eventos:
            d = (ler(ev["ocorrido_em"]) + FUSO_BRASILIA).date()
            if ini <= d < fim_sem:
                conta[ev["tipo"]] += 1
        semanas.append({"semana": ini.strftime("%d/%m"), **conta})

    # ---------------------------------------------------------------- lista de processos
    linhas = []
    for p, etapa, t, sla_atual in selecionados:
        email = usuarios.get(p["usuario_responsavel_id"])
        linhas.append({
            "form_id": p["form_id"], "operadora": p["nome_operadora"] or "—", "versao": p["version"] or 1,
            "frase": frase_situacao(dict(p), usuario_nome=nome_usuario(email)),
            "etapa_nome": etapa.nome, "area_nome": nome_area(p["area_responsavel"]) if not etapa.terminal else "—",
            "usuario_nome": nome_usuario(email) or ("não atribuído" if not etapa.terminal else "—"),
            "tempo_etapa": _dias(t["ativo_s"]) if t else "—",
            "sla": sla_atual, "sla_nome": SITUACOES_SLA[sla_atual],
            "prazo_fmt": formatar_data(t["prazo_em"]) if t and t["prazo_em"] else "",
            "prioridade_nome": PRIORIDADES.get(p["prioridade"], p["prioridade"]),
            "situacao_nome": SITUACOES[p["situacao"]] if not etapa.terminal else etapa.nome,
            "retornos": p["retornos"],
        })

    return {
        "filtros": filtros, "gerado_em": formatar_data(agora_),
        "resumo": resumo, "por_etapa": por_etapa, "por_equipe": por_equipe,
        "tempos": [{"rotulo": r, "segundos": s, "texto": _dias(s)} for r, s in tempos],
        "por_responsavel": por_responsavel, "distribuicao": distribuicao,
        "semanas": semanas, "processos": linhas,
    }


__all__ = ["calcular", "normalizar_filtros", "opcoes", "EQUIPES", "AREAS"]
