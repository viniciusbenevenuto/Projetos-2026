"""Fluxo do PTI: máquina de estados, linha do tempo, SLA, pendências e alertas.

Fonte única de verdade do estado de cada processo (Pré-PTI), igual para
Engenharia e Atacado. Módulos:
    definicao    etapas, áreas, ações e regras de transição/permissão
    tempo        tempo útil (dias úteis, horário de Brasília) e SLA
    esquema      tabelas, gatilhos de auditoria e migração dos formulários
    servico      operações transacionais (eventos, passagem de responsabilidade)
    consultas    leitura do estado, da linha do tempo e dos tempos por equipe
    indicadores  métricas consolidadas e por equipe para dashboards
"""
